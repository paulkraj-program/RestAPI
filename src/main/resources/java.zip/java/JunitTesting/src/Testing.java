
public  class Testing {

	public static void main(String[] args) {
    System.out.println("Printer is working!!");

	}

}

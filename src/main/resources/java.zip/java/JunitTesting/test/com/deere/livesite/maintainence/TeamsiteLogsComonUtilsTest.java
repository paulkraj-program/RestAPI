package com.deere.livesite.maintainence;

import org.junit.Test;

public class TeamsiteLogsComonUtilsTest {
	
	@Test
	public void getSizeValueTest() {
		
		System.out.println("Hi");
		
	}

	}

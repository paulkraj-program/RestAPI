package com.deere.dealerdatafeed.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealerDataFeedApplicationTests {

	@Test
	void contextLoads() {
	}

}

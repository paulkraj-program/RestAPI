package asset;


import java.util.List;

public class StatusMsg {
	String message;
	boolean isError;
	boolean isDefault;
	List<URLStatus> status;
	
	
	public StatusMsg() {
		super();
		this.isDefault = true;
	}
	
	public StatusMsg(String message, boolean isError) {
		super();
		this.message = message;
		this.isError = isError;
		this.isDefault = false;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the isError
	 */
	public boolean isError() {
		return isError;
	}
	/**
	 * @param isError the isError to set
	 */
	public void setError(boolean isError) {
		this.isError = isError;
	}
	/**
	 * @return the status
	 */
	public List<URLStatus> getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(List<URLStatus> status) {
		this.status = status;
	}

	/**
	 * @return the isDefault
	 */
	public boolean isDefault() {
		return isDefault;
	}

	/**
	 * @param isDefault the isDefault to set
	 */
	public void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}
	
	
	
	
}


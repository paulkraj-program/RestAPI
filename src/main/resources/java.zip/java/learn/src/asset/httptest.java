
package asset;

import org.apache.commons.io.FilenameUtils;
import org.jsoup.Jsoup;

import java.io.IOException;
import java.net.URI;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.jsoup.Connection.Response;
import org.jsoup.select.Elements;

public class httptest {

	public static void main(String args[])
	{
		//String url ="https://us-wwwdev.deere.com/en/motor-graders/670g-motor-grader/";
		//String url="https://us-wwwdev.deere.com/en/engines-and-drivetrain/marine-diesel-engines/recreational-pleasure-craft/";
		String url ="https://de-wwwdev.deere.com/de/m�hdrescher/erntevors�tze/600fd/640fd/";
		//https://us-wwwdev.deere.com/en/engines-and-drivetrain/marine-diesel-engines/, 
		//https://us-wwwdev.deere.com/en/engines-and-drivetrain/marine-diesel-engines/recreational-pleasure-craft/
		Response response = null;
		
		//int statusCode = response.statusCode();

		//System.out.println("secondLast >>"+secondLast);
		
		try {
		    Path startPath = Paths.get("D:\\Users\\ehopyr1");
		    Files.walkFileTree(startPath, new SimpleFileVisitor<Path>() {
		        @Override
		        public FileVisitResult preVisitDirectory(Path dir,
		                BasicFileAttributes attrs) {
		            System.out.println("Dir: " + dir.toString());
		            return FileVisitResult.CONTINUE;
		        }

		        @Override
		        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
		            System.out.println("File: " + file.toString());    
		            return FileVisitResult.CONTINUE;
		        }

		        @Override
		        public FileVisitResult visitFileFailed(Path file, IOException e) {
		            return FileVisitResult.CONTINUE;
		        }
		    });
		} catch (IOException e) {
		    e.printStackTrace();
		}
	try {
		response = Jsoup.connect(url).userAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.21 (KHTML, like Gecko) Chrome/19.0.1042.0 Safari/535.21").timeout(10000).execute();
		
		int statusCode = response.statusCode();
		String s = null;
		if(statusCode == 200) {
			
			org.jsoup.nodes.Document document = Jsoup.connect(url).get();
			
			
			String attrDecided="Nothing";
		  
		    String categoryPath = document.getElementsByAttributeValueContaining("name", "category-path").toString();
		    String productPath = document.getElementsByAttributeValueContaining("name", "product-path").toString();
		    System.out.println("productPath"+productPath);
		    System.out.println("categoryPath"+categoryPath);
		    
		    if(!categoryPath.isEmpty()) {
		    	attrDecided="category-path";
		    }
		    if(!productPath.isEmpty()) {
		    	attrDecided="product-path";
		    }
		    
		    

		    System.out.println("S>>>"+attrDecided);
		}
		
		System.out.println("status code :="+statusCode);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
} 
 


package asset;


import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
//import asset.URLStatus;




//import com.deere.teamsite.ui.URLStatus;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSArea;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.livesite.dom4j.Dom4jUtils;

import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;  
import org.jsoup.nodes.*;
import org.jsoup.select.Elements; 




public class AssetReport {
	private static final Logger LOGGER = Logger.getLogger(AssetReport.class.getName());
	private String transition = "";
    private String transitionComment = "FileList Created Successfully";
    private static List<CSSimpleFile> AttachFiles = new ArrayList<CSSimpleFile>();
    private static List<String> pageList = new ArrayList<String>();
    private static List<String> htmlList = new ArrayList<String>();
    private static List<String> dcrList = new ArrayList<String>();
    private static List<String> imageList = new ArrayList<String>();
    private static List<String> otherList = new ArrayList<String>();
    private static List<CSSimpleFile> SiteFiles = new ArrayList<CSSimpleFile>();
    public static final String HTML_DIR = "html/deere/";
	public static final String WEBSITE_DIR = "/website/";
	public static final String SITEMAP_XML = "sitemap.xml";
	private static final String DOMAIN_NAME_PATTERN = "(https://)*(([^/])+)";
	private static final String DEFAULT_PROPERTIES_FILE_PATH = "iw/config/johndeere/constants.properties";
	private static StatusMsg msg = null;
    
    
    private List<CSAreaRelativePath> AttachFilesRelativePath = new ArrayList<CSAreaRelativePath>();
	private static CSExternalTask CSTask;
	private static CSClient CSClient;
	private static CSWorkarea workarea;
	private static String workareaPath = "/default/main/deere/us/en/WORKAREA/shared";
	//private static final transient Logger LOGGER = Logger.getLogger(AssetReport.class);
	
	public static void main(String args[]) throws CSException, IOException {
		//CSAreaRelativePath sharedPath = new CSAreaRelativePath("/iwmnt/default/main/deere/us/en/WORKAREA/shared");
		//CSClient.getWorkarea(sharedPath, true);
	//	 CSAreaRelativePath[] relativePath = CSTask.getFiles();
	/*	System.out.println("Initial Size of Page List >>"+pageList.size());
		System.out.println("Initial Size of html List >>"+htmlList.size());
		System.out.println("Initial Size of DCR List >>"+dcrList.size());
		System.out.println("Initial Size of others List >>"+otherList.size()); */
		
		Properties prop = new Properties();
		
		try {
			prop.load(new FileInputStream(new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
			
			CSClient = Connection.getTeamSiteCSClient(prop);
			
			  
			  CSFile filesinSites = CSClient.getFile(new CSVPath(workareaPath));
			 /* if (CSDir.KIND == filesinSites.getKind()) {
		           getAllFilesInDirectory((CSDir) filesinSites);
		         }
System.out.println("Size of Page List >>"+pageList.size());
System.out.println("Size of html List >>"+htmlList.size());
System.out.println("Size of DCR List >>"+dcrList.size());
System.out.println("Size of others List >>"+otherList.size());
*/
workarea = CSClient.getWorkarea(new CSVPath(workareaPath), true);
CSFile sitemapCSFile = getSiteMapFile(workarea);
Properties siteProperties = UiUtils.readPropertiesFile(workarea, DEFAULT_PROPERTIES_FILE_PATH);
if (null == siteProperties) {
	LOGGER.error("Unable to find site properties. exiting ...");
	return;
}
String originalUrl = UiUtils.replaceRegex(siteProperties.getProperty("prodNode"), DOMAIN_NAME_PATTERN);
LOGGER.info("Original URL :" + originalUrl);
LOGGER.debug("Prod Node from constant property :" + originalUrl);


if (null != sitemapCSFile) {
	InputStream siteInStream = UiUtils.getCSFileInputStream(sitemapCSFile);
	if (null != siteInStream) {
		List<String> urls = getSiteUrls(siteInStream);
		//System.out.println("size of sitemap URLs >>"+urls.size());
		//System.out.println("List of URL :="+urls.toString());
	if (null != urls) {
			List<Future<URLStatus>> urlStatus = checkUrls(urls, originalUrl);
			for (Future<URLStatus> f : urlStatus) {
				try {
					if (f.isDone()) {
						URLStatus urlStat = f.get();
						if (urlStat.getStatus() != 200) {
							LOGGER.debug("URL is invalid or not live on website.");
							System.out.println("URL is invalid or not live on website.");
							}
						else {
							CSFile sitemapCSFileList = getSiteMapFile(workarea);
							InputStream siteInputStream = UiUtils.getCSFileInputStream(sitemapCSFileList);
							checkMetaTags(siteInputStream);
							System.out.println("Printed URLs are Valid");
						}
						}
					
					
				} catch (Exception e) {
					msg = new StatusMsg(
							"Error occured while cleaning up the sitemap, kindly try again later.", true);
					LOGGER.error("Error occured while checking threads :" + e.getMessage(), e);
				}
			}
		}
	else
		System.out.println("Not able to go inside if condition............");
		}
	}
CSClient.endSession();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	 
	 static String getMetaTag(org.jsoup.nodes.Document document, String attr) {
		 String s = new String();
		 try {
		 if(attr != null || attr !="" || attr != "null") {
		    Elements elements = document.select("meta[name=" + attr + "]");
		    for (org.jsoup.nodes.Element element : elements) {
		         s = element.attr("content");
		        if (s != null || s != "null") {} 
		        else {s = "";}
		    }
		 } 
		 
		 }catch(Exception e)
		 {
			 System.out.println("null");
		 }
		 System.out.println("Value of getMataTag: >>>"+s);
	 return s;
	}
	private static List<Future<URLStatus>> checkUrls(List<String> urls, String originalUrl) {
		ExecutorService executor = new ThreadPoolExecutor(100, 100, 0L, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<Runnable>());
		LOGGER.info("Iterating URLs in threads.. ");
		Iterator<String> urlIterator = urls.iterator();
		int noOfUrls = urls.size();
		int i = 0;
		try {
			List<Future<URLStatus>> futures = new ArrayList<>();
			while (urlIterator.hasNext()) {
				String url = urlIterator.next();
				LOGGER.debug("Executing :" + i + " out of " + noOfUrls + " --> " + url);
				Future<URLStatus> future = executor.submit(new Callable<URLStatus>() {
					@Override
					public URLStatus call() throws Exception {
						// TODO Auto-generated method stub
						LOGGER.debug(String.format("Executing to check status %s", Thread.currentThread().getName()));
						int status = UiUtils.getURLStatus(url, 1000, originalUrl);
						URLStatus urlStat = new URLStatus(url, status);
						return urlStat;
					}
				});
				futures.add(future);
				i++;
			}
			LOGGER.info("Completed iterating URLs in threads.. ");
			return futures;
		} catch (Exception e) {
			LOGGER.error("Exception Occured while checking sitemap urls.");
			return null;
		} finally {
			executor.shutdown();
		}
	}
	public static CSFile getSiteMapFile(CSWorkarea workarea) {
		CSFile csFile = null;
		if (null != workarea) {
			String workareaStr = workarea.getVPath().getPathNoServer().toString();
			String locale = UiUtils.getLocale(workareaStr);
			String sitemapFilePath = HTML_DIR + locale + WEBSITE_DIR + SITEMAP_XML;
			//String sitemapFilePath = "/default/main/deere/us/en/WORKAREA/shared/us/en/website/sitemap.xml";
			System.out.println("Workarea :" + workarea + ", Sitemap Path :" + sitemapFilePath);
			csFile = UiUtils.getCSFile(workarea, sitemapFilePath);
		}
		return csFile;
	}

	private static List<String> checkMetaTags(InputStream is) {
		List<String> urls = null;
		try{
			Document doc = Dom4jUtils.newDocument(is);
			if (null != doc) {
				Element root = doc.getRootElement();
				Iterator<Element> elements = root.elementIterator("url");
				urls = new ArrayList<String>();
				while (elements.hasNext()) {
					Element urlEle = elements.next();
					Element loc = urlEle.element("loc");
					String locStr = loc.getText();
				try {
					Response response = null;
					org.jsoup.nodes.Document document = Jsoup.connect(locStr).get();
					int statusCode = response.statusCode();
					if(statusCode == 200) {
					String descriptionProductPath = getMetaTag(document, "product-path");
					String descriptionCategoryPath = getMetaTag(document, "category-path");
					if(descriptionCategoryPath != null || descriptionCategoryPath != "") {
						System.out.println("Meta tag URL list for category path := "+ descriptionCategoryPath);
					}
					if(descriptionProductPath != null || descriptionProductPath != "") {
						System.out.println("Meta tag URL list for Product path := "+ descriptionProductPath);
					}
					}
					}catch(Exception ex) {
						return null;
					}
				}
			}
	}catch(Exception e){
		//LOGGER.error("Error Occured while parsing sitemap file :"+e.getMessage(),e);
		return null;
	}
		return urls;
}
	 
	private static List<String> getSiteUrls(InputStream is) {
		List<String> urls = null;
		List<String> productCateogryPathUrls = null;
		List<String> categoryPathUrls = null;
		List<String> otherUrls = null;
		String descriptionProductPath = null;
		String descriptionCategoryPath = null;
		try{
		Document doc = Dom4jUtils.newDocument(is);
		if (null != doc) {
			Element root = doc.getRootElement();
			Iterator<Element> elements = root.elementIterator("url");
			urls = new ArrayList<String>();
			while (elements.hasNext()) {
				Element urlEle = elements.next();
				Element loc = urlEle.element("loc");
				String locStr = loc.getText();
				
			//	System.out.println("URL in sitemap xml :="+locStr);
				try {
					Response response = null;
					
					//int statusCode = response.statusCode();
				
				response = Jsoup.connect(locStr).userAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.21 (KHTML, like Gecko) Chrome/19.0.1042.0 Safari/535.21").timeout(10000).execute();
				int statusCode = response.statusCode();
				System.out.println("Status code :="+statusCode);
				if(statusCode == 200)
				{
					org.jsoup.nodes.Document document = Jsoup.connect(locStr).get();
					descriptionProductPath = getMetaTag(document, "product-path");
					descriptionCategoryPath = getMetaTag(document, "category-path");
					String productAndCategoryMeta = descriptionProductPath+descriptionProductPath;
					System.out.println("Combined Meta data >>>"+ productAndCategoryMeta.trim());
					productCateogryPathUrls.add(productAndCategoryMeta.trim());
					/*else
					{
						otherUrls.add(locStr);
						System.out.println("Other URLs lists "+ locStr);
					}*/
					
					
				}
				else
				{
					System.out.println("Status code is not 200 := "+statusCode);
				}
				 
				 
				}catch(Exception ex) {
					System.out.println("Catch Status code is not 200 " + ex.getMessage());
					System.out.println("Catch Description Category " + descriptionCategoryPath);
					System.out.println("Catch Description Product " + descriptionProductPath);
				}
				
					 urls.add(locStr);
					
			}
		}
		}catch(Exception e){
			//LOGGER.error("Error Occured while parsing sitemap file :"+e.getMessage(),e);
			return null;
		}
		System.out.println("Total Count of Meta tags Products and Category := "+ productCateogryPathUrls.size());
		
		return urls;
	}

	private static void getAllFilesInDirectory(CSDir directory) {
         // TODO Auto-generated method stub
         List<CSSimpleFile> paths = new ArrayList<CSSimpleFile>();
         List<CSDir> queue = new ArrayList<CSDir>();
         queue.add(directory);
         while (!queue.isEmpty()) {
                         CSDir curr = queue.remove(0);
                         
                         try {
                                         for (CSNode child : curr.getChildren()) {
                                                         if (CSDir.KIND == child.getKind()) {
                                                                 queue.add((CSDir) child);
                                                         } else if (CSSimpleFile.KIND == child.getKind()) {
                                                        	 System.out.println("Procressing >>>>>>>>>>>>>>"+child.getUAI());
                                                        	if ( child.toString().contains(".page")){
                                                        		//System.out.println("Page is >>>"+child.getUAI().toString());
                                                        		pageList.add(child.getUAI().toString());
                                                        	}
                                                        	else if(child.toString().contains(".html")) {
                                                        		//System.out.println("html is >>>"+child.getUAI().toString());
                                                        		htmlList.add(child.getUAI().toString());
                                                        		
                                                        	}
                                                        	else if (child.toString().contains("/templatedata/")) {
                                                        		//System.out.println("DCR is >>>"+child.getUAI().toString());
                                                        		dcrList.add(child.getUAI().toString());
                                                        	}
                                                        	else {
                                                        		//System.out.println("Others is >>>"+child.getUAI().toString());
                                                        		otherList.add(child.getUAI().toString());
                                                        	}
                                                        	
                                                                        
                                                                         //paths.add((CSSimpleFile) child);
                                               
                                                                         
                                                         }
                                                         else {}
                                         }
                         } catch (CSObjectNotFoundException e) {
                                         // TODO Auto-generated catch block
                                         e.printStackTrace();
                         } catch (CSExpiredSessionException e) {
                                         // TODO Auto-generated catch block
                                         e.printStackTrace();
                         } catch (CSException e) {
                                         // TODO Auto-generated catch block
                                         e.printStackTrace();
                         }
         }
         
        
}

	

	
}

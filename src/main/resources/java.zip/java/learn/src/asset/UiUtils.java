package asset;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSWorkarea;

public class UiUtils {
	private static final Logger LOGGER = Logger.getLogger(UiUtils.class.getName());
	private static final int URL_STATUS_ERROR_CODE = -1;
	private static final String HTTP_REQUEST_METHOD_HEAD = "HEAD";
	private static final Pattern AREA_PATTERN = Pattern.compile("^(.*)/([^/]+)/([^/]+)/WORKAREA/([^/]+)$");
	private static final String INVALID_URL_PATTERN = ".*\\.json$|.*\\/fragment.*|.*\\/includes\\/.*|.*json\\.html$";

	public static int getURLStatus(String siteURL, int timeout, String originalUrl) {
		HttpURLConnection connection = null;
		int statusCode = URL_STATUS_ERROR_CODE;
		if (StringUtils.startsWith(siteURL, originalUrl)) {
			if (!siteURL.matches(INVALID_URL_PATTERN)) {
				try {
					URL url = new URL(siteURL);
					String query = StringUtils.trimToNull(url.getQuery());
					String path = url.getPath();
					String encodedPath = URLEncoder.encode(path, "UTF-8");
					String encPath =StringUtils.replace(encodedPath, "%2F", "/");
					StringBuilder sb = new StringBuilder();
					sb.append(url.getProtocol()).append("://").append(url.getAuthority()).append(encPath);
					if(null != query){
						sb.append(query);
					}
					String encodedUrl = sb.toString();
					URL encURL = new URL(encodedUrl);
					connection = (HttpURLConnection) encURL.openConnection();
					connection.setConnectTimeout(timeout);
					connection.setRequestMethod(HTTP_REQUEST_METHOD_HEAD);
					statusCode = connection.getResponseCode();
					LOGGER.debug("URL : " + siteURL + ", Status: " + statusCode);
				} catch (IOException e) {
					LOGGER.error("Error occured while getting status for :" + siteURL + ", Error :" + e.getMessage(),
							e);
					return statusCode;
				} finally {
					if (null != connection) {
						connection.disconnect();
					}
				}
			} else {
				return -3;
			}
		} else {
			return -2;
		}
		return statusCode;
	}

	public static String getLocale(String waLocale) {
		Matcher areaMatcher = AREA_PATTERN.matcher(waLocale);
		if (areaMatcher.matches()) {
			return areaMatcher.group(2) + "/" + areaMatcher.group(3);
		}
		return null;
	}

	public static String replaceRegex(String prodDomain, String strPattern) {
		Pattern pattern = Pattern.compile(strPattern);
		Matcher matcher = pattern.matcher(prodDomain);
		String updateDomain;
		if (matcher.find()) {
			updateDomain = matcher.group(1) + matcher.group(2);
		} else {
			updateDomain = prodDomain;
		}
		return updateDomain;
	}

	public static Properties readPropertiesFile(CSWorkarea area, String areaRelPath) {
		Properties properties = null;
		InputStream propInputStream = getCSFileInputStream(area, areaRelPath);
		if (null != propInputStream) {
			try {
				properties = new Properties();
				properties.load(propInputStream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				LOGGER.error(
						"Error occured while loading the properties :" + area.getVPath().toString() + "/" + areaRelPath,
						e);
			}
		} else {
			LOGGER.info("Could not find the property file at :" + area.getVPath().toString() + "/" + areaRelPath);
		}
		return properties;
	}

	public static InputStream getCSFileInputStream(CSWorkarea workarea, String areaRelPath) {
		CSAreaRelativePath csAreaRelPath = new CSAreaRelativePath(areaRelPath);
		InputStream istream = null;
		try {
			CSFile csFile = workarea.getFile(csAreaRelPath);
			if (null != csFile) {
				LOGGER.debug("File does exist in workarea");
				if (csFile.getKind() == CSSimpleFile.KIND) {
					LOGGER.debug("File Kind is CSSimpleFile :" + areaRelPath);
					CSSimpleFile csSimpFile = (CSSimpleFile) csFile;
					istream = csSimpFile.getInputStream(true);
					return istream;
				} else {
					LOGGER.debug("File Kind is not CSSimpleFile :" + areaRelPath);
				}
			} else {
				LOGGER.debug("File does not exist :" + areaRelPath);
			}
		} catch (Exception e) {
			LOGGER.error(
					"Error getting CSFileInputStream for file :" + workarea.getVPath().toString() + "/" + areaRelPath);
		}
		return istream;
	}

	public static InputStream getCSFileInputStream(CSFile csFile) {
		InputStream istream = null;
		try {
			if (null != csFile) {
				LOGGER.debug("File does exist in workarea");
				if (csFile.getKind() == CSSimpleFile.KIND) {
					LOGGER.debug("File Kind is CSSimpleFile :" + csFile.getVPath().toString());
					CSSimpleFile csSimpFile = (CSSimpleFile) csFile;
					istream = csSimpFile.getInputStream(true);
					return istream;
				} else {
					LOGGER.debug("File Kind is not CSSimpleFile :" + csFile.getVPath().toString());
				}
			} else {
				LOGGER.debug("File does not exist :" + csFile);
			}
		} catch (Exception e) {
			LOGGER.error("Error getting CSFileInputStream for file :" + csFile.getVPath().toString());
		}
		return istream;
	}

	public static CSFile getCSFile(CSWorkarea workarea, String areaRelPath) {
		CSAreaRelativePath csAreaRelPath = new CSAreaRelativePath(areaRelPath);
		CSFile csFile = null;
		try {
			csFile = workarea.getFile(csAreaRelPath);
			if (null != csFile) {
				LOGGER.debug("File exists in workarea :" + areaRelPath);
				if (csFile.getKind() == CSSimpleFile.KIND) {
					LOGGER.debug("File Kind is CSSimpleFile :" + areaRelPath);
					return csFile;
				} else {
					LOGGER.debug("File Kind is not CSSimpleFile :" + areaRelPath);
				}
			} else {
				LOGGER.debug("File does not exist :" + areaRelPath);
			}
		} catch (Exception e) {
			LOGGER.error("Error getting CSFile for file :" + workarea.getVPath().toString() + "/" + areaRelPath);
		}
		return csFile;
	}
}


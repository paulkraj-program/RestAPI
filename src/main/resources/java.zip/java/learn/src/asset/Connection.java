package asset;

import com.interwoven.cssdk.access.CSAuthenticationException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.factory.CSFactory;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;

public class Connection {

    public static CSClient getTeamSiteCSClient(Properties prop) throws CSAuthenticationException, CSRemoteException, CSException, IOException {
        String TSServerDomain = prop.getProperty("TeamsiteServer");
        String PROP_CSFACTORY = "com.interwoven.cssdk.factory.CSFactory";
        String PROP_CSFACRORY_IMPL = "com.interwoven.cssdk.factory.CSJavaFactory";
        Properties properties1 = new Properties(System.getProperties());
        properties1.setProperty("defaultTSServer", TSServerDomain);
        properties1.setProperty("ts.server.os", "linux");
        System.out.println("Getting CSClient instance");
        if (properties1.getProperty(PROP_CSFACTORY) == null)
            properties1.setProperty(PROP_CSFACTORY, PROP_CSFACRORY_IMPL);
        CSFactory factory = CSFactory.getFactory(properties1);
        return factory.getClientForCurrentUser(Locale.getDefault(), "teamsite", null);
    }

}

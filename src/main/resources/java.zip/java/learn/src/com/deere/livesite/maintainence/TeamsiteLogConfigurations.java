package com.deere.livesite.maintainence;

import java.util.List;

public class TeamsiteLogConfigurations {

    /*
     * Comments 
     * applicationName - Name of the Application for which the log is involved. Example-TeamSite Web Daemon.
     * logPath - Path where the log resides. Example- /opentext/Teamsite/local/logs.
     * action - The Action to be taken on the log file, it can be Delete or Archive.
     * days - The number of days for which the log is maintained , Example 30, All the old logs more than 30 days will be Deleted or Archived.
     * archivepath - The Path where the log file are Archived . Example - /tmp/Archive , a new folder (applicationName) under Archive will be created , and Archived
     * patternAdded - List of Pattern which will Satisfy the type of log to search and look for.
     * 
     */
	String applicationName;
    String logPath;
	String action;
	int days;
	String archivepath;
	List<String>patternAdded;
	String logSize;
	String logFolderSize;
	String modifiedlogFolderSize;
	List<String>Teamsitelogsdetails;
	List<String>TeamsiteDeletedLogs;
	List<String>TeamsiteDeletionFailedLogs;
	String LogDir;
	Boolean isValid;

	public Boolean getIsValid() {
		return isValid;
	}
	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}
	public String getLogDir() {
		return LogDir;
	}
	public void setLogDir(String logDir) {
		LogDir = logDir;
	}
	public List<String> getTeamsiteDeletionFailedLogs() {
		return TeamsiteDeletionFailedLogs;
	}
	public void setTeamsiteDeletionFailedLogs(List<String> teamsiteDeletionFailedLogs) {
		TeamsiteDeletionFailedLogs = teamsiteDeletionFailedLogs;
	}
	public List<String> getTeamsiteDeletedLogs() {
		return TeamsiteDeletedLogs;
	}
	public void setTeamsiteDeletedLogs(List<String> teamsiteDeletedLogs) {
		TeamsiteDeletedLogs = teamsiteDeletedLogs;
	}
	

	public List<String> getTeamsitelogsdetails() {
		return Teamsitelogsdetails;
	}
	public void setTeamsitelogsdetails(List<String> teamsitelogsdetails) {
		Teamsitelogsdetails = teamsitelogsdetails;
	}
	public String getModifiedlogFolderSize() {
		return modifiedlogFolderSize;
	}
	public void setModifiedlogFolderSize(String modifiedlogFolderSize) {
		this.modifiedlogFolderSize = modifiedlogFolderSize;
	}
	public String getLogFolderSize() {
		return logFolderSize;
	}
	public void setLogFolderSize(String logFolderSize) {
		this.logFolderSize = logFolderSize;
	}
	public String getLogSize() {
		return logSize;
	}
	public void setLogSize(String logSize) {
		this.logSize = logSize;
	}
	public List<String> getPatternAdded() {
		return patternAdded;
	}
	public void setPatternAdded(List<String> patternAdded) {
		this.patternAdded = patternAdded;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getLogPath() {
		return logPath;
	}
	public void setLogPath(String logPath) {
		this.logPath = logPath;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public String getArchivepath() {
		return archivepath;
	}
	public void setArchivepath(String archivepath) {
		this.archivepath = archivepath;
	}
	@Override
	public String toString() {
		return "TeamsiteLogConfigurations [applicationName=" + applicationName + ", logPath=" + logPath + ", action="
				+ action + ", days=" + days + ", archivepath=" + archivepath + ", patternAdded=" + patternAdded
				+ ", logSize=" + logSize + ", logFolderSize=" + logFolderSize + ", modifiedlogFolderSize="
				+ modifiedlogFolderSize + "]";
	}

	
}

package com.deere.teamsite.product;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UploadData {
	
	private UploadData() {
	    throw new IllegalStateException("Utility class");
	  }


	@SuppressWarnings("unchecked")
	public static Map<String, String> getCategoryHeaders(File s, int start) {

		XSSFWorkbook workBook = null;
		XSSFSheet excelSheet;

		XSSFCell cells;

		File excelFile = s;

		Map<String, String> map = new LinkedHashMap<>();
		Map<String, String> mapModified = new LinkedHashMap<>();
		FileInputStream fis = null;
		String[] characterString = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P",
				"Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI",
				"AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AU", "AV", "AW", "AX", "AY", "AZ" };

		if (excelFile.exists()) {
			try {
				fis = new FileInputStream(excelFile);
				workBook = new XSSFWorkbook(fis);
				XSSFSheet sheet = workBook.getSheetAt(0);
				int headerId = 0;

				for (Row row : sheet) {

					if (row.getRowNum() == start) {
						for (Cell cell : row) {

							if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
								CellRangeAddress range = getMergedRegion(cell);
								if (range != null) {

									Cell mergeValue = sheet.getRow(range.getFirstRow()).getCell(range.getFirstColumn());

									map.put(range.formatAsString(),
											mergeValue.getStringCellValue().replaceAll("[\\n]", ""));


								} 
							} else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
								
								map.put(cell.getAddress().toString(),
										cell.getStringCellValue().replaceAll("[\\n]", ""));

							}
						}
					}

				}
				for (Map.Entry<String, String> entry : map.entrySet()) {

					if (entry.getKey().contains(":")) {

						String[] a = entry.getKey().split(":");
						
						char c;
						String cellStartAddressForHeader = a[0].replaceAll("[0123456789]", "");
						
						String cellEndAddressForHeader = a[1].replaceAll("[0123456789]", "");
						int indexStartOf = ArrayUtils.indexOf(characterString, cellStartAddressForHeader);
						int indexEndOf = ArrayUtils.indexOf(characterString, cellEndAddressForHeader);

						for (int i = indexStartOf; i <= indexEndOf; i++) {
							mapModified.put(characterString[i], entry.getValue());

						}

						
					} else {
						
						String h = entry.getKey().replaceAll("[0123456789]", "");
						String g = entry.getValue();
						mapModified.put(h, g);
					}
			} 
			}catch (IOException e) {

				e.printStackTrace();
			} 
			finally {
				if(fis != null) {
					try {
						fis.close();
					} catch (IOException e) {

						e.printStackTrace();
					}
					
				}
			}
			if(workBook != null) {
				try {
					workBook.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
			}

		

		
		return (LinkedHashMap) mapModified;

	}

	public static CellRangeAddress getMergedRegion(Cell cell) {
		org.apache.poi.ss.usermodel.Sheet sheet = cell.getSheet();
		for (CellRangeAddress range : ((XSSFSheet) sheet).getMergedRegions()) {
			if (range.isInRange(cell.getRowIndex(), cell.getColumnIndex())) {
				return range;
			}
		}
		return null;
	}
}

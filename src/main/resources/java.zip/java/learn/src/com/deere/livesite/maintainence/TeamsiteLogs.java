package com.deere.livesite.maintainence;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

public class TeamsiteLogs  {

	final static String logConfig ="/iwmnt/iwadmin/main/deere/syndication/WORKAREA/shared/templatedata/LogRotation/teamsite/data/logconfig.xml";
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<TeamsiteLogConfigurations> Configurations;
		List<String>Teamsitelogs;
		Teamsitelogs = new ArrayList<String>();
		String logDetailsFolder = "/tmp/"+"123";
		String logFolder = logDetailsFolder+"/Logs";
		File dir = new File(logDetailsFolder);
		dir.mkdirs();
		ArrayList<String> result = new ArrayList<>();

		Configurations = TeamsiteLogsComonUtils.getConfigurations(logConfig);
		List<String> emailRcr = TeamsiteLogsComonUtils.getEmailRcv(logConfig);
		
		for(TeamsiteLogConfigurations Configuration:Configurations) {
			System.out.println("Getting the Object>>>>>>>>>>>>>>>>>>>>>>>"+Configuration.getIsValid());
			if(Configuration.getIsValid()) {
			Teamsitelogs = TeamsiteLogsComonUtils.getApplicationLogs(Configuration);
			String logFolderSize =  TeamsiteLogsComonUtils.getLogFolderSize(Configuration);
			Configuration.setLogFolderSize(logFolderSize);
			Configuration.setLogSize(TeamsiteLogsComonUtils.getLogsSize(Teamsitelogs));
			Configuration.setTeamsitelogsdetails(Teamsitelogs);
			Configuration.setLogDir(logFolder);
			if (Configuration.getAction().equalsIgnoreCase("Delete")) {
		    	System.out.println("<<<<<<<<<< EXECUTING DELETE  >>>>>>>>>>>");
;		    	Configuration = TeamsiteLogsComonUtils.executeDelete(Configuration);
		    }
		    if (Configuration.getAction().equalsIgnoreCase("Archive")) {
		    	System.out.println("<<<<<<<<<< EXECUTING ARCHIVE  >>>>>>>>>>>");
		    }
		    Configuration.setModifiedlogFolderSize(TeamsiteLogsComonUtils.getLogFolderSize(Configuration));
		    TeamsiteLogsComonUtils.logInformation(Configuration);
		    
		}
		
		else {
			
			Configuration.setAction("Log Path is In Valid");
		}
		}
		TeamsiteLogsComonUtils.notify(Configurations,emailRcr,logFolder);
		
		System.out.println("EMAIL ADDRESS IS >>>>>>"+emailRcr);
		//task.chooseTransition(task.getTransitions()[0], "TeamSite Logs Cleared");
	}
		
	}
	
	



package com.deere.teamsite.product;



public class testing {
	public static void main(String args[]) {
		System.out.println("Testing....");
		//byte[] iv = Encrypt.getRandomNonce(IV_LENGTH_BYTE);
		//String encryptedString = Encrypt.encrypt("ddHF8LL5DFN7qTry", iv);
		//System.out.println(encryptedString);
		
		String encryptedString = AESUtils.encrypt("ddHF8LL5DFN7qTry");
		
		System.out.println(encryptedString);
		System.out.println("Decrypted Psword id => "+AESUtils.decrypt("qiziQTQTypnGlr0pA1VM6sa/V3wYu7gECR8tnse9ZBeju5yjsfgxNkxMqXE="));
	}
}

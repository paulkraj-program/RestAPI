package com.deere.teamsite.product;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Base64;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class MySqlConnect {
	private static String secretKeys = "priy&sher";
	private static String salt = "teamsite";
	private static String exception = "Exception :";
	private static final int IV_LENGTH_BYTE = 16;
	private static final Log LOGGER = LogFactory.getLog(MySqlConnect.class);
	private MySqlConnect() {
		throw new IllegalStateException("Connection Utility class");
	}

	public static Properties getProperties(String fileName) {

		Properties prop = null;
		
		try ( 
			FileInputStream fis = new FileInputStream(fileName);
			)
		{

			prop = new Properties();
			prop.load(fis);
		} catch (FileNotFoundException fnfe) {
			LOGGER.error("FileNotFoundException Exception occured in getProperties for MySqlConnect",fnfe);
		} catch (IOException ioe) {
			LOGGER.error("IOException Exception occured in  getProperties for MySqlConnect",ioe);

		} 
		return prop;
	}

	public static Connection getConnection(Properties prop) {

		Connection con = null;
		String cred="";
		byte[] iv = MySqlConnect.getRandomNonce(IV_LENGTH_BYTE);
		String dbenc = prop.getProperty("DBENC");
		if(dbenc.equalsIgnoreCase("yes")) {
			 //cred = MySqlConnect.decrypt(prop.getProperty("DBCRED"), iv);
			cred=AESUtils.decrypt(prop.getProperty("DBCRED"));
		}
		else {
		String encryptedString = MySqlConnect.encrypt(prop.getProperty("DBCRED"), iv);
		cred = MySqlConnect.decrypt(encryptedString, iv);
		}
		String dbUrl = prop.getProperty("DBURL");
		
		String dbUser = prop.getProperty("DBUSER");
		try {
			con = DriverManager.getConnection(dbUrl, dbUser, cred);
		} catch (Exception e) {
			LOGGER.error(exception,e);
		}
		return con;
}

	public static String encrypt(String strToEncrypt, byte[] bv) {
		try {

			IvParameterSpec ivspec = new IvParameterSpec(bv);

			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKeys.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

			// Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); //Non complaint
			// code

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
		} catch (Exception e) {
			LOGGER.error(exception,e);
		}
		return null;
	}

	public static String decrypt(String strToDecrypt, byte[] bv) {
		try {

			IvParameterSpec ivspec = new IvParameterSpec(bv);

			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKeys.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		} catch (Exception e) {
			LOGGER.error(exception,e);
		}
		return null;
	}

	public static byte[] getRandomNonce(int numBytes) {
		byte[] nonce = new byte[numBytes];
		new SecureRandom().nextBytes(nonce);
		return nonce;
	}
}

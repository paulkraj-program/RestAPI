package com.deere.teamsite.product;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class ExecuteUpload  {
	

	
	public static void main(String[] args){

		String iwmnt = "/iwmnt";
		String excelFilePath = "";
		String credFile = "/iwmnt/iwadmin/main/deere/syndication/WORKAREA/shared/configuration/customupload.properties";
		Properties prop = MySqlConnect.getProperties(credFile);
		Connection dbConnection = null;

		//excelFilePath = "/iwmnt/iwadmin/main/config/WORKAREA/shared/Tractor.xlsx";
		excelFilePath = args[0];
		File excelFile = new File(excelFilePath);

		//String catName = "test6";
		String catName = args[1];
		String pd = catName + "_category";
		String pdInfo = catName + "_product_information";

		StringBuilder sql = new StringBuilder("CREATE TABLE IF NOT EXISTS " + pd);
		sql.append("(model_series VARCHAR(255), ");
		sql.append(" SKU VARCHAR(255), ");
		sql.append(" model VARCHAR(255) not NULL, ");
		sql.append(" PRIMARY KEY ( Model ))");

		StringBuilder pdInfoSql = new StringBuilder("CREATE TABLE IF NOT EXISTS " + pdInfo);
		pdInfoSql.append("(model_series VARCHAR(255), ");
		pdInfoSql.append(" SKU VARCHAR(255), ");
		pdInfoSql.append(" model VARCHAR(255) not NULL, ");
		pdInfoSql.append(" category VARCHAR(255) not NULL, ");
		pdInfoSql.append(" subcategory VARCHAR(255) not NULL, ");
		pdInfoSql.append(" filter VARCHAR(255) not NULL, ");
		pdInfoSql.append(" value VARCHAR(255) not NULL)");

		System.out.println("Product file in Excel is  >>"+excelFilePath);
		System.out.println("Product Category in Excel is  >>"+catName);
		
		try {
			dbConnection = MySqlConnect.getConnection(prop); 
			Statement stmt = (Statement) dbConnection.createStatement();
			DatabaseMetaData dbm = (DatabaseMetaData) dbConnection.getMetaData();
			ResultSet tables = dbm.getTables(null, null, pd, null);
			ResultSet pfInfotable = dbm.getTables(null, null, pdInfo, null);
			System.out.println("<<<<<<<<<< Executing the Upload >>>>>>>>>>>");
			if (tables.next()) {
				System.out.println("Table exits");
				stmt.executeUpdate("DELETE FROM   " + pd);

			} else {
				System.out.println("Table doesn't exits");

				stmt.executeUpdate(sql.toString());
			}

			if (pfInfotable.next()) {
				System.out.println("Table exits");
				stmt.executeUpdate("DELETE FROM   " + pdInfo);

			} else {
				System.out.println("Creating the Table " + pdInfoSql.toString());
				System.out.println("Table pdInfo doesn't exits");

				stmt.executeUpdate(pdInfoSql.toString());

			}
			
			buildProductsTable(prop,excelFile, pd);
			buildProductsInformationTable(prop,excelFile, pdInfo);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(dbConnection != null) {
				 try {
					dbConnection.close();
				} catch (SQLException e) {
                    e.printStackTrace();
				}
			}
		}
	//	task.chooseTransition(task.getTransitions()[0], "Uploaded the Product Data");
	}

	public static String quote(String s) {
		return new StringBuilder().append('\'').append(s).append('\'').toString();
	}

	private static void buildProductsTable(Properties prop,File excelFile, String pd) {

		//LOGGER.debug("<<<<<<<<<<<<<<<<<<<  Executing buildProductsTable  >>>>>>>>>>>>");
		Connection dbConnection  = MySqlConnect.getConnection(prop);
		//LOGGER.debug("Connection established is >> "+dbConnection);
		if (excelFile.exists()) {
			PreparedStatement st = null;
			Statement stmt = null;
			FileInputStream fisProducts = null;
			XSSFWorkbook productWorkBook = null;
			try {
				stmt = (Statement) dbConnection.createStatement();
				fisProducts = new FileInputStream(excelFile);
				productWorkBook = new XSSFWorkbook(fisProducts);
				XSSFSheet productSheet = productWorkBook.getSheetAt(0);
				for (Row productRow : productSheet) {
					if (productRow.getRowNum() > 2) {

						String modelseries = quote(productRow.getCell(0).toString());
						String sku = quote(productRow.getCell(1).toString());
						String model = quote(productRow.getCell(2).toString());

						String sql = "INSERT INTO " + pd + " VALUES (" + modelseries + "," + sku + "," + model + ")";
						String queryCheck = "SELECT * from " + pd + " WHERE model = ?";
						st = (PreparedStatement) dbConnection.prepareStatement(queryCheck);
						st.setString(1, productRow.getCell(2).toString());
						ResultSet rs = st.executeQuery();
						if (rs.next()) {
							//LOGGER.debug("Model is " + rs.getString("model"));

						} else {

							stmt.executeUpdate(sql);
						}
					}
				}
				
			} catch (SQLException e) {

				e.printStackTrace();
			} catch (IOException e1) {

				e1.printStackTrace();
			} finally {
				if(dbConnection != null) {
					 try {
						dbConnection.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}
				if (stmt != null) {

					try {
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}

				}
				if (fisProducts != null) {
					try {
						fisProducts.close();
					} catch (IOException e) {

						e.printStackTrace();
					}
				}
				if (st != null) {
					try {
						st.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (productWorkBook != null) {
					try {
						productWorkBook.close();
					} catch (IOException e) {

						e.printStackTrace();
					}
				}
			}
		}

	}

	public static CellRangeAddress getMergedRegion(Cell cell) {
		org.apache.poi.ss.usermodel.Sheet sheet = cell.getSheet();
		for (CellRangeAddress range : ((XSSFSheet) sheet).getMergedRegions()) {
			if (range.isInRange(cell.getRowIndex(), cell.getColumnIndex())) {
				return range;
			}
		}
		return null;
	}

	private static void buildProductsInformationTable(Properties prop,File excelFile, String pdInfo) {

		//LOGGER.debug("<<<<<<<<<<<<<<<<<<<  Executing buildProductsInformationTable  >>>>>>>>>>>>");
		Connection dbConnection = MySqlConnect.getConnection(prop);
		//LOGGER.debug("Connection established is >> "+dbConnection);
		

			if (excelFile.exists()) {
				Map<String, String> map = new LinkedHashMap<>();
				Map<String, String> mdyMap = new LinkedHashMap<>();
				Map<String, String> mdyMapHeaders;
				mdyMapHeaders = UploadData.getCategoryHeaders(excelFile, 0);
				Map<String, String> filterMap = UploadData.getCategoryHeaders(excelFile, 1);
				XSSFWorkbook workBook = null;
				FileInputStream fis = null;
				Statement stmt = null;
				
				try {
				stmt = (Statement) dbConnection.createStatement();	
				fis = new FileInputStream(excelFile);

				workBook = new XSSFWorkbook(fis);
				XSSFSheet sheet = workBook.getSheetAt(0);
				XSSFRow r = sheet.getRow(0);
				int colCount = r.getLastCellNum();
				int rowCount = sheet.getLastRowNum() + 1;

				String category = "";
				String filter = "";
				String subcategory = "";
				String categoryCheck = "";
				String cellValueString = "";
				for (Row row : sheet) {

					if (row.getRowNum() == 2) {
						//LOGGER.debug("Row Number 2 condition  is " + row.getRowNum());
						for (Cell cell : row) {
							System.out.println("");
							System.out.println("cell.getAddress()" + cell.getAddress().toString());
							System.out.println("cell Type is " + cell.getCellType());
							System.out.println("cell address Type is " + cell.getAddress().toString());

							if (cell.getCellType() == 1) {
								mdyMap.put(cell.getAddress().toString().replaceAll("[0123456789]", ""),
										cell.getStringCellValue().replaceAll("[\\n]", ""));
							}
							if (cell.getCellType() == 0) {
								String val = NumberToTextConverter.toText(cell.getNumericCellValue());
								mdyMap.put(cell.getAddress().toString().replaceAll("[0123456789]", ""),
										val.replaceAll("[\\n]", ""));
							}
						}
					}
					if (row.getRowNum() > 2) {
						System.out.println("Row Number is " + row.getRowNum());
						for (int i = 0; i < colCount; i++) {
							Cell cellValue = row.getCell(i);
							String cellAddress = row.getCell(i).getAddress().toString();
							String cellAddressForHeader = cellAddress.replaceAll("[0123456789]", "");
							System.out.println(row.getCell(0) + ">>>" + row.getCell(1) + ">>>" + row.getCell(2) + ">>>"
									+ row.getRowNum() + ">>>" + mdyMap.get(cellAddressForHeader) + ">>>" + cellAddress
									+ ">>>" + cellValue);

							categoryCheck = mdyMap.get(cellAddressForHeader);
							
								category = mdyMapHeaders.get(cellAddressForHeader);
								subcategory = mdyMap.get(cellAddressForHeader);
								filter = filterMap.get(cellAddressForHeader);

							
							cellValueString = cellValue.toString();
							if (cellValue.toString().isEmpty() || cellValue.toString().equalsIgnoreCase("")) {
								cellValueString = "No";
							} else if (cellValue.toString().equalsIgnoreCase("x")) {
								cellValueString = "Yes";
							}
							String modelseries = quote(row.getCell(0).toString());
							String sku = quote(row.getCell(1).toString());
							String model = quote(row.getCell(2).toString());
							
							if(!category.contains("|") && !filter.equalsIgnoreCase("range") && category.contains("[")) {
								  
									   String secondvalue = category.substring(category.indexOf("[")+1,category.indexOf("]"));
									  // String firstvalue = category.replaceAll("\\s*\\([^\\)]*\\)\\s*", " ");
									   String firstvalue = category.substring(0, category.indexOf("["));
									   category=firstvalue.trim() + "|" + secondvalue;
									   
								   }
							   
							category = quote(category);
							subcategory = quote(subcategory);
							cellValueString = quote(cellValueString);
							filter = quote(filter);
							String pdInfosql = "INSERT INTO " + pdInfo + " VALUES (" + modelseries + "," + sku + ","
									+ model + "," + category + "," + subcategory + "," + filter.toLowerCase() + "," + cellValueString
									+ ")";

							stmt.executeUpdate(pdInfosql);
							

						}
					}

				}
			

			

		} catch (IOException | SQLException e) {

			e.printStackTrace();
		} finally {
			if(dbConnection != null) {
				 try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
			if (workBook != null) {
				try {
					workBook.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
			if (stmt != null) {

				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}

		}
	}
	}
}


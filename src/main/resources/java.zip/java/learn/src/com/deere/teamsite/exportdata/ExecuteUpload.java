package com.deere.teamsite.exportdata;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.deere.teamsite.exportdata.*;



public class ExecuteUpload implements CSURLExternalTask {

	private static final transient Log LOGGER = LogFactory.getLog(ExecuteUpload.class);
	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		// TODO Auto-generated method stub

		
		String IWMNT = "/iwmnt";
		Boolean executeData=false;
		Boolean createTabel=false;
		String catName=task.getWorkflow().getVariable("cat"); 
		String pd =catName+"_category";
		String pdInfo = catName+"_product_information";
		String excelFilePath= new String();
		CSAreaRelativePath[] files = task.getFiles();
		for(CSAreaRelativePath file:files) {
		
			excelFilePath = IWMNT + task.getArea().getUAI() + "/" + file.getParentPath().toString() + "/" + file.getName();
			
		}
		LOGGER.debug("excelFilePath >>>>>>>>>"+excelFilePath);
		FileInputStream fis;
		
		File excelFile= new File(excelFilePath);
		
		/*String sql = "CREATE TABLE IF NOT EXISTS REGISTRATION " +
                "(id INTEGER not NULL, " +
                " first VARCHAR(255), " + 
                " last VARCHAR(255), " + 
                " age INTEGER, " + 
                " PRIMARY KEY ( id ))";*/
		StringBuilder sql = new StringBuilder("CREATE TABLE IF NOT EXISTS "+pd);
        sql.append("(model_series VARCHAR(255), ");
        sql.append(" SKU VARCHAR(255), "); 
        sql.append(" model VARCHAR(255) not NULL, "); 
        sql.append(" PRIMARY KEY ( Model ))");
        
        StringBuilder pdInfoSql = new StringBuilder("CREATE TABLE IF NOT EXISTS "+pdInfo);
        pdInfoSql.append("(model_series VARCHAR(255), ");
        pdInfoSql.append(" SKU VARCHAR(255), "); 
        pdInfoSql.append(" model VARCHAR(255) not NULL, "); 
        pdInfoSql.append(" category VARCHAR(255) not NULL, ");
        pdInfoSql.append(" subcategory VARCHAR(255) not NULL, ");
        pdInfoSql.append(" value VARCHAR(255) not NULL)");
        
        
        LOGGER.debug("SQL Builder >>>"+sql.toString());
        try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://teamsite16rdsd.marketing-devl.us.i06.c01.johndeerecloud.com:3306/tsdb_cat","tsdbuser","ddHF8LL5DFN7qTry");  
			
			
			Statement stmt = (Statement) con.createStatement();
			DatabaseMetaData dbm = (DatabaseMetaData) con.getMetaData();
			ResultSet tables = dbm.getTables(null, null, pd , null);
			ResultSet pfInfotable = dbm.getTables(null, null, pdInfo , null);
			LOGGER.debug("<<<<<<<<<< Executing the Upload >>>>>>>>>>>");
			if (tables.next()) {
				LOGGER.debug("Table exits");
				  stmt.executeUpdate("DELETE FROM   "+pd);
				  
				}
				else {
					LOGGER.debug("Table doesn't exits");
					
			        stmt.executeUpdate(sql.toString());
				}
			if (pfInfotable.next()) {
				LOGGER.debug("Table exits");
				  stmt.executeUpdate("DELETE FROM   "+pdInfo);
				  
				}
				else {
					LOGGER.debug("Creating the Table "+pdInfoSql.toString());
					LOGGER.debug("Table pdInfo doesn't exits");
					
			        stmt.executeUpdate(pdInfoSql.toString());
				}
			
			BuildProductsTable(con,excelFile,pd);
			BuildProductsInformationTable(con,excelFile,pdInfo);
			
			
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		

		
	}
	private static void BuildProductsInformationTable(Connection con, File excelFile, String pdInfo) throws IOException, SQLException {
		// TODO Auto-generated method stub
		XSSFWorkbook workBook;
		XSSFSheet excelSheet;
		Map<String,String> map=new LinkedHashMap<String,String>();
		Map<String,String> mdyMap=new LinkedHashMap<String,String>();
		Map<String,String> mdyMapHeaders = UploadData.getCategoryHeaders(excelFile);
		XSSFCell cells;
		if (excelFile.exists()) {
			FileInputStream fis = new FileInputStream(excelFile);

		   workBook = new XSSFWorkbook(fis);
		   XSSFSheet sheet = workBook.getSheetAt(0);
           XSSFRow r = sheet.getRow(0);
		   int colCount = r.getLastCellNum();
		   int rowCount = sheet.getLastRowNum() +1;
		   
		   String category = new String();
		   String subcategory = new String();
		   String categoryCheck = new String();
		   String cellValueString = new String();
		   System.out.println("Row Count is "+rowCount);
		   System.out.println("Col Count is "+colCount);
		    
			    for (Row row : sheet) {
			    	
				    	if(row.getRowNum() == 1) {
					        for (Cell cell : row) {
					        	
						            
						            	//map.put(cell.getAddress().toString(), cell.getStringCellValue());
						            	mdyMap.put(cell.getAddress().toString().substring(0, cell.getAddress().toString().length() - 1), cell.getStringCellValue().replaceAll("[\\n]", ""));
						            
					        }
				    	}
				    	if(row.getRowNum() > 1) {
				    	//System.out.println("Row Number is "+row.getRowNum());
				    	for(int i =0; i<colCount;i++) {
				    	 Cell cellValue = row.getCell(i);
				    	 String cellAddress = row.getCell(i).getAddress().toString();
				    	// String cellAddressForHeader = cellAddress.substring(0, cellAddress.length() - 1);
				    	 String cellAddressForHeader = cellAddress.replaceAll("[0123456789]","");
				    	 LOGGER.debug(row.getCell(0)+">>>"+row.getCell(1)+">>>"+row.getCell(2)+">>>"+row.getRowNum()+">>>"+mdyMap.get(cellAddressForHeader)+">>>"+cellAddress+">>>"+cellValue);
				    	 
				    	 categoryCheck = mdyMap.get(cellAddressForHeader).toString();
				    	// System.out.println("categoryCheck >>"+categoryCheck);
				    	 if(categoryCheck.contains("|")) {
				    		 
				    		 System.out.println("categoryCheck >>"+categoryCheck+" contains |");
				    		 String[] categoryValues= categoryCheck.split("\\|");
				    		// System.out.println("categoryValues from the array are >>"+categoryValues.length);
				    		 //category = categoryValues[0];
				    		 //subcategory = categoryValues[1];
				    		 category = mdyMapHeaders.get(cellAddressForHeader);
				    		 subcategory=mdyMap.get(cellAddressForHeader);
				    		 //System.out.println("category is >>"+category);
				    		// System.out.println("subcategory >>"+subcategory);
				    	 }
				    	 else {
				    		 category = mdyMapHeaders.get(cellAddressForHeader);
				    		 subcategory=mdyMap.get(cellAddressForHeader);
				    		 /*System.out.println("categoryCheck >>"+categoryCheck+" doesnt contains |");
				    		 System.out.println("category is >>"+category);
				    		 System.out.println("subcategory >>"+subcategory);*/
				    	 }
				    	 cellValueString = cellValue.toString();
				    	 if(cellValue.toString().isEmpty() || cellValue.toString().equalsIgnoreCase("") ) {
				    		 cellValueString = "No";
				    	 }
				    	 else if(cellValue.toString().equalsIgnoreCase("x")) {
				    		 cellValueString ="Yes";
				    	 }
				    	   String model_series =quote(row.getCell(0).toString());
						   String sku=quote(row.getCell(1).toString());
						   String model=quote(row.getCell(2).toString()); 
						   category =quote(category);
						   subcategory =quote(subcategory);
						   cellValueString =quote(cellValueString);
				    	 String pdInfosql = "INSERT INTO " + pdInfo +" VALUES ("+model_series+","+sku+","+model+","+category+","+subcategory+","+cellValueString+")";
				    	 Statement  stmt = (Statement) con.createStatement();
				    	 stmt.executeUpdate(pdInfosql);
				    	}
				    	}
			    	
					    
					}
		    }
			    for (Map.Entry<String, String> entry : map.entrySet()) {
		    		//System.out.println(entry.getKey() + "->" + entry.getValue().toString().replaceAll("[\\n]", ""));
				    
				    
				    }
			    for (Map.Entry<String, String> mdyMapentry : mdyMap.entrySet()) {
		    		//System.out.println(mdyMapentry.getKey() + "->" + mdyMapentry.getValue());
				    
				    
				    }
		    
	}
	public static String quote(String s) {
	    return new StringBuilder()
	        .append('\'')
	        .append(s)
	        .append('\'')
	        .toString();
	}
	private static void BuildProductsTable(Connection con, File excelFile, String pd) throws IOException, SQLException {
		// TODO Auto-generated method stub
		
		if (excelFile.exists()) {
			Statement  stmt = (Statement) con.createStatement();
		      
			FileInputStream fisProducts = new FileInputStream(excelFile);

			XSSFWorkbook productWorkBook = new XSSFWorkbook(fisProducts);
		    XSSFSheet productSheet = productWorkBook.getSheetAt(0);
            XSSFRow product = productSheet.getRow(0);
		   int colCount = product.getLastCellNum();
		   int rowCount = productSheet.getLastRowNum() +1;
		   for (Row productRow : productSheet) {
			   if(productRow.getRowNum() > 1) {
				   
					   //System.out.println(productRow.getRowNum()+">>>>"+productRow.getCell(0)+">>>"+productRow.getCell(1)+">>>"+productRow.getCell(2));
					   
					   String model_series =quote(productRow.getCell(0).toString());
					   String sku=quote(productRow.getCell(1).toString());
					   String model=quote(productRow.getCell(2).toString());
					      
					   String sql = "INSERT INTO " + pd +" VALUES ("+model_series+","+sku+","+model+")";
					   //System.out.println(">>"+sql);
					   String queryCheck = "SELECT * from "+pd+" WHERE model = ?";
			            PreparedStatement st = (PreparedStatement) con.prepareStatement(queryCheck);
			            st.setString(1, productRow.getCell(2).toString());
			            ResultSet rs = st.executeQuery();
			            if(rs.next()) {
			            	LOGGER.debug("Model is "+rs.getString("model"));
			                
			            }else{
			            
					       stmt.executeUpdate(sql);
			            }
			   }
		   }
		   
		}
		
	}

	public static CellRangeAddress getMergedRegion(Cell cell) {
	    org.apache.poi.ss.usermodel.Sheet sheet = cell.getSheet();
	    for (CellRangeAddress range : ((XSSFSheet) sheet).getMergedRegions()) {
	        if (range.isInRange(cell.getRowIndex(), cell.getColumnIndex())) {
	            return range;
	        }
	    }
	    return null;
	}

}

package learn.teamsite.workflows;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.cssdk.workflow.CSWorkflowEngine;

public class WorkflowExecute implements CSURLExternalTask {

	
	public static final transient Logger LOGGER = Logger.getLogger(WorkflowExecute.class);
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		// TODO Auto-generated method stub
		List<CSAreaRelativePath>pFilesToBeAttached = new ArrayList();

			
            String selectedFiles = task.getWorkflow().getVariable("selectedFiles");
            String[] selectedFilesArray = selectedFiles.split(",");
            String wfFiles ="";

            LOGGER.debug("selectedFiles is >>>"+selectedFiles);

            CSAreaRelativePath[] allFilesAttached = task.getFiles();
            String SubmitDCR = task.getVariable("SubmitDCR");
            if(SubmitDCR.equalsIgnoreCase("false")) {
            	task.detachFiles(allFilesAttached);
            }
            
            for (String fileFromArray: selectedFilesArray)
            {
            	String selectedFile = task.getArea().getUAI()+File.separator+fileFromArray;
            	LOGGER.debug("selectedFile is >>>>>>>>"+selectedFile);
            	CSVPath csvpathSelectedFile = new CSVPath(selectedFile);
            	pFilesToBeAttached.add(new CSAreaRelativePath(csvpathSelectedFile.getAreaRelativePath()));
            	
            }
            task.attachFiles((CSAreaRelativePath[])pFilesToBeAttached.toArray(new CSAreaRelativePath[pFilesToBeAttached.size()]));
	        
		
        String defaultTransition =task.getTransitions()[0];
        task.chooseTransition(defaultTransition, "Files attached Successfully");

		
	}

}

package learn;

import java.io.File;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jcajce.provider.symmetric.AES;




public class Passwd {
	private static String secretKey = "priy&sher";
	private static String salt = "teamsite";
	private static final int IV_LENGTH_BYTE = 16;
	public static void main(String[] args) 
	{
		
		byte[] iv = Passwd.getRandomNonce(IV_LENGTH_BYTE);
	    String originalString = "howtodoinjava.com";
	    
	    String encryptedString = Passwd.encrypt(originalString, iv) ;
	    String decryptedString = Passwd.decrypt(encryptedString, iv) ;
	      
	    System.out.println(originalString);
	    System.out.println(encryptedString);
	    System.out.println(decryptedString);
	    
	    List<String> c = new ArrayList<>();
	    System.out.println(">>>"+c.size());
	    System.out.println(File.separator);
	    
	    HashMap<String, Integer> hash_map = new HashMap<String, Integer>(); 
	    
        // Mapping int values to string keys 
        hash_map.put("Geeks", 10); 
        hash_map.put("4", 15); 
        hash_map.put("Geeks", 20); 
        hash_map.put("Welcomes", 25); 
        hash_map.put("You", 30); 
        
        System.out.println("The Value is: " + hash_map.get("Geeks")); 
        System.out.println("The Value is: " + hash_map.get("Geek")); 
	}

	public static String encrypt(String strToEncrypt, byte[] bv) 
	{
	    try
	    {
	       
	        IvParameterSpec ivspec = new IvParameterSpec(bv);
	         
	        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
	        KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
	        SecretKey tmp = factory.generateSecret(spec);
	        SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
	         
	        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
	        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
	        return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
	    } 
	    catch (Exception e) 
	    {
	        System.out.println("Error while encrypting: " + e.toString());
	    }
	    return null;
	}
	public static String decrypt(String strToDecrypt, byte[] bv) {
	    try
	    {
	        
	        IvParameterSpec ivspec = new IvParameterSpec(bv);
	         
	        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
	        KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
	        SecretKey tmp = factory.generateSecret(spec);
	        SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
	        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
	        return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	    } 
	    catch (Exception e) {
	        System.out.println("Error while decrypting: " + e.toString());
	    }
	    return null;
	}
	public static byte[] getRandomNonce(int numBytes) {
        byte[] nonce = new byte[numBytes];
        new SecureRandom().nextBytes(nonce);
        return nonce;
    }
}
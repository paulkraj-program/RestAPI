package learn;



public class CommonTest {
	
	public static void main (String[] args) {
		
		System.out.println("Hi");
		
	}



}
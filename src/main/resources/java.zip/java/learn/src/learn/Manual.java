package learn;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Manual {
	
	public static void main(String[] args) {
		
		String category = "Machine Form[form]";
		String filter = "radio";
		
		if (!category.contains("|") && !filter.equalsIgnoreCase("range")
				&& category.contains("[")) {

			String secondvalue = category.substring(category.indexOf("[") + 1,
					category.indexOf("]"));
			//String firstvalue = category.replaceAll("\\s*\\([^\\)]*\\)\\s*", " ");
			String firstvalue = category.substring(0, category.indexOf("["));
			category = firstvalue.trim() + "|" + secondvalue;
		}
		
		System.out.println(category);
		
		String subCat = "Max Ballastable [lbs per hp]";

		Pattern pattern = Pattern.compile("\\[(.*?)\\]");
		Matcher matcher = pattern.matcher(subCat);

		while (matcher.find()) {
			subCat = matcher.group(1);

		}
		subCat = subCat.replaceAll("(^ )|( $)", "");
		System.out.println("subCat "+subCat);
		
		
		
	}

}

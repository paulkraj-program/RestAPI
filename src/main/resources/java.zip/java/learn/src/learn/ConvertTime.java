package learn;
import java.io.File;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.io.FileUtils;

public class ConvertTime {

    private static final String DATE_FORMAT = "MM/dd/yyyy hh:mm:ss";
    static ZoneId istZoneId = ZoneId.of("Asia/Kolkata");
    static ZoneId estZoneId = ZoneId.of("America/New_York");
    static ZoneId csttZoneId = ZoneId.of("America/Chicago");
    static ZoneId cestZoneId = ZoneId.of("Europe/Berlin");
    static ZoneId aestZoneId = ZoneId.of("Australia/Melbourne");

    public static void main(String[] args) {
    String timezone="";
     String dateInString = "09/15/2020 11:09:00";
     //LocalDateTime date  = LocalDateTime.parse(dateInString, DateTimeFormatter.ofPattern(DATE_FORMAT));

        
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern ("MM/dd/yyyy HH:mm:ss");
        OffsetDateTime date = LocalDateTime.parse(dateInString, dtf).atZone(istZoneId).toOffsetDateTime();
        String ISTime = date.atZoneSameInstant(istZoneId).format(dtf);
        String ESTime = date.atZoneSameInstant(estZoneId).format(dtf);
        String CSTime = date.atZoneSameInstant(csttZoneId).format(dtf);
        String CESTime = date.atZoneSameInstant(cestZoneId).format(dtf);
        String AESTime = date.atZoneSameInstant(aestZoneId).format(dtf);
        
        
        System.out.println("IST >> "+ISTime);
        System.out.println("EST >> "+ESTime);
        System.out.println("CST >> "+ CSTime);
        System.out.println("CEST >> "+ CESTime);
        System.out.println("AEST >> "+ AESTime);
        
        if (timezone != null && !timezone.equalsIgnoreCase("")){
        	System.out.println("Here 1");
        }else {
        	System.out.println("Here 2");
        }
    

    String h ="D:\\Users\\ehopyr1\\Documents";
    long size = FileUtils.sizeOfDirectory(new File(h));
    
    System.out.println("Size is KB >>>"+(double)size/1024.0);
    System.out.println("Size is GB >>>"+(double)size/1048576.0);
    System.out.println("Size is TB >>>"+(double)size/1073741824.0);
}
}
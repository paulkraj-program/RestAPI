package learn.teamsite.workflows;

import java.io.File;
import java.util.ArrayList;

import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;


public class CheckDependencies implements CSURLExternalTask {


	
    private String transition = "";
    private String transitionComment = "FileList Created Successfully";
    private List<CSSimpleFile> AttachFiles = new ArrayList<CSSimpleFile>();
    private List<String> AttachFilesArray = new ArrayList<String>();
    private List<CSSimpleFile> SiteFiles = new ArrayList<CSSimpleFile>();
    private List<CSSimpleFile> ParentPage1 = new ArrayList<CSSimpleFile>();
    private List<CSSimpleFile> ParentPage2 = new ArrayList<CSSimpleFile>();
    private List<CSAreaRelativePath> AttachFilesRelativePath = new ArrayList<CSAreaRelativePath>();
    private static transient Logger logger = Logger.getLogger(CheckDependencies.class);
	public void execute(CSClient CSClient, CSExternalTask CSTask, Hashtable arg2) throws CSException {
		
       
        CSAreaRelativePath[] relativePath = CSTask.getFiles();
        String workareaPath = CSTask.getArea().getUAI()+File.separator+"sites";
        logger.info("workareaPath>>>"+workareaPath);
        CSFile filesinSites = CSClient.getFile(new CSVPath(workareaPath));
        if (CSDir.KIND == filesinSites.getKind()) {
           SiteFiles.addAll(getAllFilesInDirectory(CSTask, (CSDir) filesinSites,"PAGE"));
    	}
         logger.debug("SiteFiles size is >>>>>"+SiteFiles.size());

        
        for (CSAreaRelativePath file : relativePath) {

        	CSFile CSfile = CSTask.getArea().getFile(file); 
        	//logger.info("CSfile Kind is "+CSfile.getName().toString() +">>> "+CSfile.getKind());

        	
        	if (CSSimpleFile.KIND == CSfile.getKind()) {
        		AttachFiles.add((CSSimpleFile)CSfile);
        	}
        	if (CSDir.KIND == CSfile.getKind()) {
        		
        		AttachFiles.addAll(getAllFilesInDirectory(CSTask, (CSDir) CSfile, "ALL"));
        		
        	}


        }


        
        
        
        
        for(CSSimpleFile ad : AttachFiles) {
        	
        	String bb = ad.getUAI();
        	//logger.debug("bbbbbbbbbbb >>>>>"+bb);
        	CSVPath cvb = new CSVPath(bb.trim());
        	AttachFilesRelativePath.add(new CSAreaRelativePath(cvb.getAreaRelativePath()));
        	
        }
        
        
        for(CSAreaRelativePath ad1 : AttachFilesRelativePath) {
        	String ss= ad1.getParentPath().toString()+File.separator+ad1.getName();
        	//logger.debug("File attached int the workflow is>>>>>>>>>>>>> "+ss);
        	AttachFilesArray.add(ad1.getParentPath().toString()+File.separator+ad1.getName());
        	
        	
        	
        }

        for(CSSimpleFile SiteFile: SiteFiles)  {
       	 
       	 logger.debug("SiteFile>>>>"+SiteFile.getVPath().toString());
       	 try {
       		logger.debug(">>>>>>>>>>>>>>>>>>>>Checking the association>>>>>>>>>>>>>>>");
       		if(SiteFile instanceof CSSimpleFile) {
       	  CSAssociation[] PrimaryDependencies = SiteFile.getParentAssociations(null);
        	
       	 for(CSAssociation as:PrimaryDependencies) {
       		
       		
       		if (as.getParent().getUAI().contains("/templatedata/")) {
       		 //logger.debug("as>>"+as.getParent().getUAI());
       		 String as1 = as.getParent().getUAI();
       		 String [] arr = as1.split("/STAGING/");
       		 if(arr.length>1) {
       		//logger.debug("arr[1>>>>>>>>"+arr[1]);
       		if(AttachFilesArray.contains(arr[1].trim()))
       			ParentPage1.add(SiteFile);
       		}
       		}
       	 }
       	 
       	 }}
       	 catch(Exception e) {
       		 e.printStackTrace();
       	 }
       	

        }

        

        

        logger.debug("ParentPage1 >>>"+ParentPage1.size());
        logger.debug("ParentPage2 >>>"+ParentPage2.size());
       // CSTask.detachFiles(relativePath);
        //CSTask.attachFiles((CSAreaRelativePath[]) filesToBeAttached.toArray(new CSAreaRelativePath[filesToBeAttached.size()]));
        logger.info("End:: AttachDirectories.execute" );
        String defaultTransition = CSTask.getTransitions()[0];
		this.transition = defaultTransition;
		CSTask.chooseTransition(this.transition,transitionComment);
}
	private static List<CSSimpleFile> getAllFilesInDirectory(CSTask task, CSDir directory,String type) {
		// TODO Auto-generated method stub
		List<CSSimpleFile> paths = new ArrayList<CSSimpleFile>();
		List<CSDir> queue = new ArrayList<CSDir>();
		queue.add(directory);
		while (!queue.isEmpty()) {
			CSDir curr = queue.remove(0);
			
			try {
				for (CSNode child : curr.getChildren()) {
					if (CSDir.KIND == child.getKind()) {
						queue.add((CSDir) child);
					} else if (CSSimpleFile.KIND == child.getKind()) {
						
						if(type.equals("ALL")) {
						paths.add((CSSimpleFile) child);
					     }
						else if (type.equals("PAGE")){
							
							if(child.toString().contains(".page")) {
								paths.add((CSSimpleFile) child);
							}
						} 	
						else {}
					}
				}
			} catch (CSObjectNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSExpiredSessionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return paths;
	}


}

package learn;

import com.mchange.v2.lang.StringUtils;

public class MatchBrackets{

    public static int matchBrackets(String brackets){

      int open = 0;
      int count =0;

     for(int i=0;i<brackets.length();i++){
        if(brackets.charAt(i)=='('){
        open++;
        }else if(brackets.charAt(i)==')'){
         open--;
        }
        if(open<0){
        count++;
        open++;
     }
  }
  return count+open;
}

  public static void main(String[] args) {
 String s = "Machine Form";
  
 String answer = s.substring(s.indexOf("(")+1,s.indexOf(")"));
  System.out.println(answer);
  //System.out.println(matchBrackets("))))"));
}}
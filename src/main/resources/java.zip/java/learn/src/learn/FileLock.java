package learn;

import java.util.List;

import com.interwoven.cssdk.filesys.CSFile;

public class FileLock {
	String filePath;
	String lockMessage;
	String lockType;
	String jobIds;
	List<FileLock> dependencyLocks;
	CSFile file;
	String fileType;
	
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public CSFile getFile() {
		return file;
	}
	public void setFile(CSFile file) {
		this.file = file;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getLockMessage() {
		return lockMessage;
	}
	public void setLockMessage(String lockMessage) {
		this.lockMessage = lockMessage;
	}
	public List<FileLock> getDependencyLocks() {
		return dependencyLocks;
	}
	public void setDependencyLocks(List<FileLock> dependencyLocks) {
		this.dependencyLocks = dependencyLocks;
	}
	public String getJobIds() {
		return jobIds;
	}
	public void setJobIds(String jobIds) {
		this.jobIds = jobIds;
	}
	public String getLockType() {
		return lockType;
	}
	public void setLockType(String lockType) {
		this.lockType = lockType;
	}
	
	@Override
	public String toString() {
		return "FileLock [filePath=" + filePath + ", lockMessage=" + lockMessage + ", lockType=" + lockType
				+ ", jobIds=" + jobIds + ", dependencyLocks=" + dependencyLocks + ", file=" + file + ", fileType="
				+ fileType + "]";
	}
}

package learn.teamsite.workflows;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class Teamsitelogs {
	



	public static List<String> getAlllogFiles(String mPath) {
	// TODO Auto-generated method stub
	List<String>mlogFiles = new ArrayList<String>();
	try {
	    Path startPath = Paths.get(mPath);
	    Files.walkFileTree(startPath, new SimpleFileVisitor<Path>() {
	        @Override
	        public FileVisitResult preVisitDirectory(Path dir,
	                BasicFileAttributes attrs) {
	            System.out.println("Dir: " + dir.toString());
	            return FileVisitResult.CONTINUE;
	        }

	        @Override
	        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
	            //System.out.println("File:>>>>>> " + file.toString()); 
	            
	            mlogFiles.add(file.toString());
	            return FileVisitResult.CONTINUE;
	        }

	        @Override
	        public FileVisitResult visitFileFailed(Path file, IOException e) {
	            return FileVisitResult.CONTINUE;
	        }
	    });
	} catch (IOException e) {
	    e.printStackTrace();
	}
	return mlogFiles;
}
public List<String> getApplicationLogs(String logLocation, String[] patternSet){
		List<String> logfiles = new ArrayList<String>();
		List<String> ssllogfiles = new ArrayList<String>();
		logfiles = getAlllogFiles(logLocation);
		for(String t:logfiles) {
			Path path = Paths.get(t); 
			Path fileName = path.getFileName(); 
	        //System.out.println("FileName: "+ fileName.toString());
	        for(String patternCheck:patternSet) {
	        	Pattern pattern = Pattern.compile(patternCheck);
	    	    
		        Matcher match = pattern.matcher(fileName.toString());
		        if(match.matches()) {
		           System.out.println("The file >>"+t + " matches the Pattern");
		           ssllogfiles.add(t);
		        }else {
		        	 //System.out.println("The file >>"+t + " doesnot matches the Pattern");
		        }
	        }
		}
		   
	return ssllogfiles;
    }

public static void deleteFilesOlderThanNdays(int daysBack, String dirWay) {

	File directory = new File(dirWay);
	if(directory.exists()){

	    File[] listFiles = directory.listFiles();
	    long purgeTime = System.currentTimeMillis() - (daysBack * 24 * 60 * 60 * 1000);
	    for(File listFile : listFiles) {
	        if(listFile.lastModified() < purgeTime) {
	            if(!listFile.delete()) {
	                System.err.println("Unable to delete file: " + listFile);
	            }
	         }
	      }
	   }
	}
}

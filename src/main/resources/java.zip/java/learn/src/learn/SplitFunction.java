package learn;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class SplitFunction {

	public static void main(String[] args) {
		
String s = "//dce-ts16d-d.tal.deere.com/default/main/component-guide/WORKAREA/shared/sites/Component Guide/Page Element/Navigation/Vertical JavaScript Flyout.page"; 
	String arp="//dce-ts16d-d.tal.deere.com/default/main/component-guide/WORKAREA/shared/";
	String[] sr =s.split(arp);
		/*
		 * System.out.println(">>"+sr.length); System.out.println("0>>"+sr[0]);
		 * System.out.println("1>>"+sr[1]);
		 */
	
	String a = "one,two";
	String[] b = a.split(",");
	System.out.println("Length is >>>"+b.length);
	String x ="";
	String Data ="Tue Sep 25 06:16:19 EDT 2018";
	
	for (int i=0;i<b.length;i++) {
		System.out.println("Values are >>>"+b[i]);
		 x+= "<file path=\""+b[i]+"\" comment=\"\"/>";
	}
	System.out.println("X is >>>>>>>"+x);
	String bc ="/default/main/deere/de/de/WORKAREA/shared/html/deere/de/de/website/magazines/publication.html";
	//String bc ="refr/ghh/magazines/publication.html";
	//de/website/magazines/publication.html
		
	String wa ="/default/main/deere/de/de/WORKAREA/shared";
	String[] filePathArray = bc.split(wa);
	System.out.println("filePathArray>>>>>>"+filePathArray.length);
	//String htmlFile = filePathArray[filePathArray.length -4]+File.separator+filePathArray[filePathArray.length -3]+File.separator+filePathArray[filePathArray.length -2]+File.separator+filePathArray[filePathArray.length -1];
	System.out.println("filePathArray>>>>>>"+filePathArray[1]);
	
	
	//System.out.println("filePathArray>>>>>>"+htmlFile);
	String[] sq = Data.split("EDT");
	System.out.println("sq>>"+sq.length);
	System.out.println("sq>>"+sq[1].trim());
	
	Map <String,String> m = new HashMap<String,String>();
	
	m.put("a", "A");
	m.put("b", "B");
	String g =  m.get("c");
	System.out.println("Map Get>>>"+m.get("c"));
	if(g == null) {
		System.out.println("Here>>> in IF");
	}
	else {
		System.out.println("Here>>> in else");
	}
	
	
	
			
	}
}

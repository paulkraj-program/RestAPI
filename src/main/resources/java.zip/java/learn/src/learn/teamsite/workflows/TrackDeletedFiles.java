package learn.teamsite.workflows;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.deere.teamsite.datasource.AcrossWorkflowDataSource;
import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

public class TrackDeletedFiles implements CSURLExternalTask {

	private static final  Logger LOGGER = Logger.getLogger(TrackDeletedFiles.class);
	private static List<CSDir> queue ;
	private List<CSSimpleFile> SiteFiles; 
	public void execute(CSClient csclient, CSExternalTask task, Hashtable hash) throws CSException {
		// TODO Auto-generated method stub
		  try {
		SiteFiles = new ArrayList<CSSimpleFile>();
		String workareaPath = task.getArea().getUAI();
		LOGGER.debug("Workarea Selected is >>> "+workareaPath);
	     
			CSAreaRelativePath[] attachedFiles = task.getFiles();
			task.detachFiles(attachedFiles);
			CSFile filesinSites = csclient.getFile(new CSVPath(workareaPath));
			if (CSDir.KIND == filesinSites.getKind()) {
		          SiteFiles.addAll(getAllFilesInDirectory(task,(CSDir) filesinSites));
		    	}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
        
		task.chooseTransition(task.getTransitions()[0], "Report Generated");
	}

	private static List<CSSimpleFile> getAllFilesInDirectory(CSExternalTask task,CSDir directory)  {
		// TODO Auto-generated method stub
		List<FileAttributes> list=new ArrayList<FileAttributes>();
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFFont font  = workbook.createFont();
		XSSFSheet sheet = workbook.createSheet("Deleted Assets");
		
		
		List<CSSimpleFile> paths = new ArrayList<CSSimpleFile>();
		
		queue = new ArrayList<CSDir>();
		paths.clear();
		queue.clear();
		queue.add(directory);
		while (!queue.isEmpty()) {
			CSDir curr = queue.remove(0);
			
			
			
				try {
					for (CSNode child : curr.getChildren()) {
						
						FileAttributes deletedFileAttributes = new FileAttributes();
						if (CSDir.KIND == child.getKind()) {
							queue.add((CSDir) child);
							
						}
						else if(child.getKind() == 3) {
							CSHole cshole = (CSHole) child;
							String fileHoleYearString = new String();
							String fileHoleDate = new String();
							String fileHoleDateEDT = new String();
							//String fileHoleYear= new String();
							String fileHolePath = cshole.getVPath().getAreaRelativePath().toString();
							String fileHoleID = cshole.getLastModifier().getName().toString() ;
							System.out.println("Processing for >>>>>"+fileHolePath);
							if(cshole.getAttributeModificationDate().toString()!=null) {
								fileHoleDateEDT = cshole.getAttributeModificationDate().toString();
								if (fileHoleDateEDT.contains("EDT")) {
									String[] fileHoleDateArray = fileHoleDateEDT.split("EDT");
									if(fileHoleDateArray.length>1) {
										fileHoleYearString =fileHoleDateArray[1].toString().trim();
									}
								}
								else if(fileHoleDateEDT.contains("EST")){
									String[] fileHoleDateArray = fileHoleDateEDT.split("EST");
									if(fileHoleDateArray.length>1) {
										fileHoleYearString =fileHoleDateArray[1].toString().trim();
									}
									
								}
								else {}
							}
							fileHoleDate= cshole.getAttributeModificationDate().toString();
							LOGGER.debug(fileHolePath+">>>"+">>>>>"+fileHoleID+">>>"+fileHoleDate);
							if(child.getVPath().toString().contains(".page")) {
								deletedFileAttributes.setType("PAGE");
							}
							else if(child.getVPath().toString().contains(".html")) {
								deletedFileAttributes.setType("HTML");
							}
							else if(child.getVPath().toString().contains("/templatedata/")) {
								deletedFileAttributes.setType("DCR");
							}
							else {
								deletedFileAttributes.setType("OTHERS");
								}
						
							deletedFileAttributes.setFile(fileHolePath);
							deletedFileAttributes.setOwner(fileHoleID); 
							deletedFileAttributes.setDate(fileHoleDate);
							deletedFileAttributes.setYearString(fileHoleYearString);
							list.add(deletedFileAttributes);
							
							
						}

						else {}
					}
				} catch (CSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

		}
		
		 try {
		    	Row frow = sheet.createRow(0); 
		    
		 		Cell cell = frow.createCell(0);
		 		cell.setCellValue("Asset Path"); 
		 		
		 		cell = frow.createCell(1);
		 		cell.setCellValue("User Id");
		 		cell = frow.createCell(2);
		 		cell.setCellValue("Asset Type");
		 		cell = frow.createCell(3);
		 		cell.setCellValue("Date");
		 		cell = frow.createCell(4);
		 		cell.setCellValue("Year");
		 		sheet.setAutoFilter(CellRangeAddress.valueOf("A1:E1"));
		 		sheet.setColumnWidth(0,105*256);
		 		sheet.setColumnWidth(1,15*256);
		 		sheet.setColumnWidth(2,15*256);
		 		sheet.setColumnWidth(3,27*256);
		 		sheet.setColumnWidth(4,8*256);
		 		
		 		
		 		
		 		
		 		
		 		for(int colIndex =0; colIndex<5; colIndex++) {
		 		
		 			Cell headerCell = frow.getCell(colIndex);
		 			CellStyle  cellstyle = headerCell.getCellStyle();
		 			font.setBold(true);
		 			cellstyle.setFont(font);
		 			headerCell.setCellStyle(cellstyle);
		 	
		 			
		 		}
		 		
		 		 
		 		 int rownum = 1; 
		 		 
		 		 if(!list.isEmpty()) {
		 			 for (FileAttributes file : list)
		 			 { 
		 				 Row row = sheet.createRow(rownum++); 
		 				 createList(file, row);
		 			  
		 			 }
		 	     //String ReportFile = "/opentext/TeamSite/local/bin/custom/URLContentCleanUp/DeletedFiles_"+task.getId()+".xlsx";
		 	     //File file = new File(ReportFile);
		 	     //file.createNewFile();
		 		String ReportFile = "/tmp/DeletedFiles_"+task.getId()+".xlsx";
		 		File file = new File(ReportFile);
				file.createNewFile();
				FileOutputStream out = new FileOutputStream(new File(ReportFile)); 
				 
				 workbook.write(out); 
				 out.close();
				 task.getWorkflow().setVariable("ReportStatus", "yes");
				 task.getWorkflow().setVariable("ReportPath", ReportFile);
				 LOGGER.debug("Report path is  Selected is >>> "+task.getWorkflow().getVariable("ReportPath"));
				 }
				 else{
					 task.getWorkflow().setVariable("ReportStatus", "no");
				 }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSAuthorizationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSRemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSObjectNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSExpiredSessionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		 
		return paths;
	}
	private static void createList(FileAttributes fObject, Row row) // creating cells for each row
	{
	        Cell cell = row.createCell(0);
	        cell.setCellValue(fObject.getFile());
	     
	        cell = row.createCell(1);
	        cell.setCellValue(fObject.getOwner());
	        
	        cell = row.createCell(2);
	        cell.setCellValue(fObject.getType());
	        
	        cell = row.createCell(3);
	        cell.setCellValue(fObject.getDate());
	        
	        cell = row.createCell(4);
	        cell.setCellValue(fObject.getYearString());
	     
	       
	    }

}

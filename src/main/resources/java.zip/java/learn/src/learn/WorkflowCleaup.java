package learn;

import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Hashtable;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.cssdk.workflow.CSWorkflow;

public class WorkflowCleaup implements CSURLExternalTask {

	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {

		Date currentDate = new Date();
		CSWorkflow jobs[] = client.getWorkflowEngine().getWorkflowsByQuery("<wfquery><active/></wfquery>");
		for(CSWorkflow job:jobs) {
			Date jobDate = job.getActivationDate();
			
			
		}
		
	}

}

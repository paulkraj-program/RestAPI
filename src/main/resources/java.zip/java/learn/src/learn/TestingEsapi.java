package learn;

import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;

public class TestingEsapi implements CSURLExternalTask{
	private static final Logger LOGGER = Logger.getLogger(TestingEsapi.class);
	
	@Override
	public void execute(CSClient client, CSExternalTask task, Hashtable hash) throws CSException {
		
		LOGGER.debug("-----------------------------START----------------------------------------------");
		if(System.getProperty("org.owasp.esapi.resources") == null)
		{
			LOGGER.debug("-----------------------------Setting up the Property----------------------------------------------");
			System.setProperty("org.owasp.esapi.resources", "/opentext/TeamSite/local/config/esapi");
		}
		
		
		
		
		
		LOGGER.debug("Workarea for getVPath().getName().toString() >>>:" + ESAPI.encoder().encodeForHTML(client.getWorkarea(new CSVPath("/default/main/deere/us/en/WORKAREA/shared"),true).getVPath().getName().toString()));
	   LOGGER.debug("Workarea :" + ESAPI.encoder().encodeForHTML(client.getWorkarea(new CSVPath("/default/main/deere/us/en/WORKAREA/shared"),true).getVPath().getAreaName().toString()));

		LOGGER.debug("-----------------------------END----------------------------------------------");
		
		String defaultTransition =task.getTransitions()[0];
        task.chooseTransition(defaultTransition, "Files attached Successfully");

	}

}

package learn;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelSheet {

	public static void main(String[] args) throws IOException {
		
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFFont font  = workbook.createFont();
		XSSFSheet sheet = workbook.createSheet("Deleted Assets");
		Row frow = sheet.createRow(0); 
	    
 		Cell cell = frow.createCell(0);
 		cell.setCellValue("Asset Path"); 
 		
 		cell = frow.createCell(1);
 		cell.setCellValue("User Id");
 		cell = frow.createCell(2);
 		cell.setCellValue("Asset Type");
 		cell = frow.createCell(3);
 		cell.setCellValue("Date");
 		cell = frow.createCell(4);
 		cell.setCellValue("Year");
 		sheet.setAutoFilter(CellRangeAddress.valueOf("A1:E1"));
 		sheet.setColumnWidth(0,105*256);
 		sheet.setColumnWidth(1,15*256);
 		sheet.setColumnWidth(2,15*256);
 		sheet.setColumnWidth(3,27*256);
 		sheet.setColumnWidth(4,8*256);
 		
 		for(int colIndex =0; colIndex<5; colIndex++) {
	 		
 			Cell headerCell = frow.getCell(colIndex);
 			System.out.println("headerCell>>"+headerCell.getStringCellValue().toString());
 			CellStyle  cellstyle = headerCell.getCellStyle();
 			font.setBold(true);
 			
 			cellstyle.setFont(font);
 			headerCell.setCellStyle(cellstyle);
 			
 			String ReportFile = "D:\\Users\\ehopyr1\\Documents\\1.xlsx";
	 		
			FileOutputStream out = new FileOutputStream(new File(ReportFile)); 
			 
			 workbook.write(out); 
			 out.close();
 	
 			
 		}
 		
	}
}

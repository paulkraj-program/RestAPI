package learn;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import org.owasp.esapi.ESAPI;




public class test {
	private static final Logger LOGGER = Logger.getLogger(test.class);
	
	public static void main(String[] args) {
		
		//
		
		
		/*if(System.getProperty("org.owasp.esapi.resources") == null) 
		{
			System.out.println("------------------its NULLLLL");
			System.setProperty("org.owasp.esapi.resources", "D:\\Users\\ehopyr1\\1\\esapi");
		}else {
			System.out.println("------------------its NOT NULLLLL");
		}*/
		//System.out.println("------------------"+System.getProperty("org.owasp.esapi.resources"));
		Map<String, String> map = new HashMap<String, String>();
		String a ="//dce-ts16d-d.tal.deere.com/default/main/deere/gb/en/WORKAREA/shared";
		String b ="/default/main/deere/gb/en/WORKAREA/shared/sites/en/us/jk/p.page";
		String c = "us/en";
		a = a.replaceAll("//(.*)/default", "/default");
		
		System.out.println("a >>>>"+a);
		hire hi = new hire();
		String message ="Hi Paul \\\\n\\\\nweb � 2017-04-12 17:47:08,957 [main] INFO Amount reversed successfully";
		message = message.replace( '\n' ,  '_' ).replace( '\r' , '_' ).replace( '\t' , '_' );
		String hirename = hi.name(message);
		
		String[] bd = b.split(a+"/");
		
		System.out.println("b array>>"+bd[1]);
		
		String []  n = c.split("/");
		System.out.println("Size  of c is "+n.length + ">>>>"+n[1]);
		map.put("aB","A");
		map.put("Ab","B");
		map.put("c","C");
		map.put("d","D");
		String s = "https://de-wwwdev.deere.com/a/b/c/d/e/f/a/b/C/d/E/F/Ab";
		String hostname="https://de-wwwdev.deere.com";
		String []z = s.split(hostname);
		System.out.println("z[]>>"+z[1]);
		
		String[] y = z[1].split("/");
		List<String>g = new ArrayList<>();
		for(int i =1 ;i<y.length;i++) {
			System.out.println("y split is >>"+y[i]);
			
			String h=map.get(y[i]);
			if(h!=null) {
				g.add(h);
			}
			else {
				g.add(y[i]);
			}
		}
		System.out.println("g list is >"+g.toString());
		String result = String.join("/",g);
		System.out.println("g listtoString is >"+result+">>"+File.separator);
		
		
		Pattern blackListLanguagePattern = Pattern.compile ("en");
		System.out.println("Patern is "+blackListLanguagePattern.toString());
		System.out.println("Translation Mapping File Path " + ESAPI.encoder().encodeForHTML(blackListLanguagePattern.toString()));
	}

}
package learn;

public class task {

	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private int id;
	@Override
	public String toString() {
		return "task [name=" + name + ", id=" + id + "]";
	}

	
}

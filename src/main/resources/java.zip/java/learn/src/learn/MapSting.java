package learn;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MapSting {

	public static void main(String[] args) {
	Map<String,String>a = new HashMap<String,String>();
	a.put("tillage/2100-minimum-till-ripper   /index.html","/iwmnt/default/main/deere/us/en/WORKAREA/shared/html/deere/us/en/website/products/tillage/2100-minimum-till-ripper/index.html");
	a.put("row-crop-tractors/row-crop-6-family/6210r-tractor/fragment-carousel-related-products.html", "/iwmnt/default/main/deere/us/en/WORKAREA/shared/html/deere/us/en/website/products/tractors/row-crop-tractors/row-crop-6-family/6210r-tractor/fragment-carousel-related-products.html, news-releases/2017/engines-drivetrain/2017mar7-new-industry-standard-engine.html=/iwmnt/default/main/deere/us/en/WORKAREA/shared/html/deere/us/en/website/our-company/news-and-announcements/news-releases/2017/engines-drivetrain/2017mar7-new-industry-standard-engine.html\r");
	//String b = "tillage/2100-minimum-till-ripper/index.html";
	//System.out.println(">>> "+a.get(b));
	/*String tempurlPath ="/en/hay-forage/mowing/windrowers-platforms/w155/ ";
	tempurlPath = tempurlPath.replaceAll("\\s+", "");
	if(tempurlPath.endsWith("/")) {

		tempurlPath= tempurlPath.substring(0, tempurlPath.length() - 1);
	 }
	System.out.println("Printing All tempurlPath >>>>>>>>>>>>>>>>>>>>>>>>"+tempurlPath);
	*/
	String toReplace ="/en/";
	//String UrlPathwithoutDomain ="mowers/commercial-mowers/quiktrak-mowers/652r-mod-mower";
	String UrlPathwithoutDomain ="generator-drive-/final-tier-4/6068c-p550";
	UrlPathwithoutDomain = UrlPathwithoutDomain.replaceFirst(toReplace, "");
	String tempurlPath =UrlPathwithoutDomain;
	String[] b = UrlPathwithoutDomain.split("/");
	String paramaterhtmlFile = new String();
	
	
	if(!tempurlPath.contains(".html")) {
		tempurlPath = tempurlPath+"/"+"index.html";
	}
	String[] tempurlPathArray =tempurlPath.split("/");
	System.out.println(">>>>"+tempurlPathArray.length);
	if(tempurlPathArray.length>4) {
		paramaterhtmlFile = tempurlPathArray[tempurlPathArray.length -4]+File.separator+tempurlPathArray[tempurlPathArray.length -3]+File.separator+tempurlPathArray[tempurlPathArray.length -2]+File.separator+tempurlPathArray[tempurlPathArray.length -1];
		}
	else {
		paramaterhtmlFile =tempurlPath;
	}
    System.out.println(paramaterhtmlFile);
}
}

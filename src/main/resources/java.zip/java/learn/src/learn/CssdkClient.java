package learn;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.Properties;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.factory.CSFactory;
import com.interwoven.cssdk.factory.CSJavaFactory;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSPathCommentPair;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;

public class CssdkClient {
	public static CSClient csClient = null;
	public static void main(String[] args) throws IOException {
		
		
		// TODO Auto-generated method stub
		FileInputStream cssdkfile = null;
		BufferedReader reader = null;
		
		try {
			Runtime run = Runtime.getRuntime();
			Process proc;
			proc = run.exec("hostname");
			BufferedInputStream in = new BufferedInputStream(proc.getInputStream());
			reader = new BufferedReader(new InputStreamReader(in));
			Properties properties = new Properties();
			cssdkfile = new FileInputStream("D:\\Users\\ehopyr1\\Documents\\cssdk.cfg");
			properties.load(cssdkfile);
			CSFactory csFactory = CSJavaFactory.getFactory(properties);
			System.out.println("csFactory >>>"+csFactory.toString());
			csClient = csFactory.getClient("ehopyr1", "", "Germany123",Locale.getDefault(), "iw-cc", "");
			System.out.println("CSSDK CLIENT CONNECTION IS "+csClient.isValid());
			
			
			String file ="//dce-ts16d-d.tal.deere.com/default/main/deere/gb/en/WORKAREA/shared/templatedata/deere/link-list-simple/data/products/compact-utility-tractors/link-list-compact-utility-tractors-brochure";
			CSVPath waPath = new CSVPath(file);
			//System.out.println(waPath.getAreaRelativePath());
			CSWorkarea csWorkarea = csClient.getWorkarea(waPath.getArea(), false);
		System.out.println("csWorkarea check "+waPath.getAreaRelativePath().toString());
			CSAreaRelativePath teamsitefileAreaPathCheck = new CSAreaRelativePath(waPath.getAreaRelativePath().toString());
			//System.out.println(csWorkarea.getFile(teamsitefileAreaPathCheck).getCreationDate());
			CSPathCommentPair[] CommentPair = new CSPathCommentPair[1];
			String Flag = "OVERWRITE_ALL";
			System.out.println("waPath "+waPath.getName());
			//CommentPair[0]= new CSPathCommentPair(waPath.getAreaRelativePath(),"");
			//csWorkarea.submitDirect("Migrated Content", "Migration2", CommentPair, 0 );
			/*
			 * if (!csWorkarea.getFile(teamsitefileAreaPathCheck).isReadable() ){
			 * 
			 * System.out.println("FILE DOESN'T EXISTS");
			 * 
			 * } else { System.out.println("FILE EXISTS"); }
			 */
		} catch (Exception e) {
			

		
	}

}
}

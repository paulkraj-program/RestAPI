package learn;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class Encrypt {
	
	
		public static void main(String args[]) {
		System.out.println("Testing....");
		//byte[] iv = Encrypt.getRandomNonce(IV_LENGTH_BYTE);
		//String encryptedString = Encrypt.encrypt("ddHF8LL5DFN7qTry", iv);
		//System.out.println(encryptedString);
		
		String encryptedString = AESUtils.encrypt("ddHF8LL5DFN7qTry");
		
		System.out.println(encryptedString);
		System.out.println("Decrypted Psword id => "+AESUtils.decrypt("qiziQTQTypnGlr0pA1VM6sa/V3wYu7gECR8tnse9ZBeju5yjsfgxNkxMqXE="));
	}

	
	
}

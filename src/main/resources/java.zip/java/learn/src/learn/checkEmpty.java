package learn;

import java.util.HashMap;
import java.util.Map;

public class checkEmpty {
	
    
	public static Map<String, String> regionalSiteList = new HashMap<String, String>();
	
	public static void main(String args[]) {
		
		//System.out.println("Working !!!");
		
		String s = "privacy-and-data";
		String g = "";
		
		readregionalSiteList();
		
		System.out.println("Working !!!  "+regionalSiteList);
		
		if (s.contains("privacy")){
			
			regionalSiteList.get("in");
			
			System.out.println("Working !!!  "+regionalSiteList.get("in"));
			
			g = regionalSiteList.get("ASIA");
			
			System.out.println("Working G !!!  "+g);
			
		}
		
	}


	public static void readregionalSiteList() {
		// TODO Auto-generated method stub
		
		regionalSiteList.put("ASIA", "asia");
		regionalSiteList.put("latinamerica", "latin-america");
		
		
	}
	


}

package learn.teamsite.workflows;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class LogHandler {
	  public static void main(String argv[]) {

		    try {

			File fXmlFile = new File("D:\\Users\\ehopyr1\\Documents\\log\\1.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
           doc.getDocumentElement().normalize();

			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName("target");

			System.out.println("----------------------------");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
                    
					
					System.out.println("Name : " + eElement.getElementsByTagName("name").item(0).getTextContent());
					System.out.println("Logpath : " + eElement.getElementsByTagName("logpath").item(0).getTextContent());
					System.out.println("Action : " + eElement.getElementsByTagName("action").item(0).getTextContent());
					System.out.println("Days : " + eElement.getElementsByTagName("days").item(0).getTextContent());
					System.out.println("Archivepath : " + eElement.getElementsByTagName("archivepath").item(0).getTextContent());
					NodeList patternList = eElement.getElementsByTagName("pattern");
					for (int i = 0; i < patternList.getLength(); i++) {
						Node pNode = patternList.item(i);
						if (nNode.getNodeType() == Node.ELEMENT_NODE) {
							Element patternElement = (Element) pNode;
						System.out.println("Regex Pattern : " + patternElement.getElementsByTagName("regexpattern").item(0).getTextContent());
						}
					}
				}
				
				
			}
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		  }

		}


package learn;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class patternmatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "db-67908.log";
		//s ="2010-06-29";
		//Pattern pattern = Pattern.compile("content_center.log.([0-9]|[10]|[0-9][0-9])");
		Pattern pattern = Pattern.compile("db-([0-9]+).log");
	    
	        Matcher match = pattern.matcher(s);
	        if (match.matches()) {
	           System.out.println("Match found" + match.matches());
	        }
	        else{
	        	System.out.println("Matches found Not Found !!!" + match.matches());
	        }
	        }
	    }
				
	



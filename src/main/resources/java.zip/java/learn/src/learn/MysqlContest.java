package learn;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mysql.jdbc.PreparedStatement;  

public class MysqlContest{  
	
	public static void main(String args[]){  
		try{  
			
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://teamsite16rdsd.marketing-devl.us.i06.c01.johndeerecloud.com:3306/tsdb_cat","tsdbuser","ddHF8LL5DFN7qTry");  
		//here sonoo is database name, root is username and password  
		//Statement stmt=con.createStatement();  
		//ResultSet rs=stmt.executeQuery("select * from acl_entries");  
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Map<String,String> mp= new LinkedHashMap<>();
		List<String> result= new ArrayList<>();
		String retrieveQuery = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA='tsdb_cat'";
		//retrieveQuery = retrieveQuery.replace("<TABLE_NAME>", "largetractor_product_information");
		String subCat = "";
		String cat = "";
		String value = "";
		String filter= "";
		try {
			stmt = (PreparedStatement) con.prepareStatement(retrieveQuery);
			
			rs = stmt.executeQuery();

			

			while (rs.next()) {
				if(rs.getString("TABLE_NAME").contains("product_information")) {
					
					String tableName = rs.getString("TABLE_NAME");
					tableName = tableName.replace("_product_information", "");
					
					System.out.println(">>>>"+tableName);
					result.add(tableName);
				
			}
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			System.out.println("Closing the connection");
			con.close();
		}
		
	
	
		}catch(Exception e)
		{ 
			System.out.println(e);
		}  
	}  
}  



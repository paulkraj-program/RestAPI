package learn;

public class stringURL {
	
	public static void main(String[] args) {
		
		String attrValue ="https://dealerlocator.deere.com/servlet/country=TT?locale=en_TT";
		String sourceCountry = "tt";
		String targetCountry ="bg";
		String sourceLocale="en";
		String QUESTION = "?";
		String UNDERSCORE = "_";
		String key="bg_BG";
		System.out.println("attrValue" + attrValue);
		if ((!attrValue.isEmpty()) || (attrValue != null)) {
			int index = attrValue.indexOf("country");
			if (index > 0) {
				String firstHalfStr = attrValue.substring(0, index);
				
				System.out.println("firstHalfStr>>>"+firstHalfStr);
				String secondHalfStr = attrValue.substring(index);
				System.out.println("secondHalfStr>>>"+secondHalfStr);
				int index1 = secondHalfStr.indexOf('?');
				String countrySubStr = secondHalfStr.substring(0, index1);
				
				System.out.println("countrySubStr>>>"+countrySubStr);
				
				
				
				int localeStrIndex = secondHalfStr.indexOf("locale");
				if (localeStrIndex > 0) {
					String localeSubStr = secondHalfStr
							.substring(localeStrIndex);
					
					System.out.println("localeSubStr>>>"+localeSubStr);
					
					String replacedCountrySubStr = countrySubStr
							.replace(sourceCountry.toUpperCase(), targetCountry.toUpperCase());
					
					System.out.println("replacedCountrySubStr>>>>"+replacedCountrySubStr);
					
					String replacedlocaleSubStr = localeSubStr.replace(
							sourceLocale + UNDERSCORE + sourceCountry.toUpperCase(), key);
					
					System.out.println("replacedlocaleSubStr>>>>"+replacedlocaleSubStr);
					
					
					
					
					String finalReplacedFullStr = firstHalfStr
							+ replacedCountrySubStr + QUESTION
							+ replacedlocaleSubStr;
					
					
					
					System.out.println(
							"Before modifing productsummary_primaryctaurl value: "
									+ attrValue);
					System.out.println(
							"After modifing productsummary_primaryctaurl value: "
									+ finalReplacedFullStr);
					
				}

			} else {
				
			}

		} 
	}

}

package learn;

import java.util.HashMap;
import java.util.List;

public class FileLockCheck {
	String Country;
	String Locale;
	String JobOwner;
	int JobId;
	List<String> File;
	HashMap<String, String> map;
	public HashMap<String, String> getMap() {
		return map;
	}
	public void setMap(HashMap<String, String> map) {
		this.map = map;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getLocale() {
		return Locale;
	}
	public void setLocale(String locale) {
		Locale = locale;
	}
	public String getJobOwner() {
		return JobOwner;
	}
	public void setJobOwner(String jobOwner) {
		JobOwner = jobOwner;
	}
	public int getJobId() {
		return JobId;
	}
	public void setJobId(int jobId) {
		JobId = jobId;
	}
	public List<String> getFile() {
		return File;
	}
	public void setFile(List<String> file) {
		File = file;
	}
	@Override
	public String toString() {
		return "FileLockCheck [Country=" + Country + ", Locale=" + Locale + ", JobOwner=" + JobOwner + ", JobId="
				+ JobId + ", File=" + File + "]";
	}

}

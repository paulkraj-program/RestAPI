package learn;

import org.owasp.esapi.ESAPI;

public class hire {
	
	String name(String n){
		n = "hi" + n;
		System.out.println("Namefrom hire is >>>>>>>>>>>>>>"+ESAPI.encoder().encodeForHTML(n));
		return n;
		}

}

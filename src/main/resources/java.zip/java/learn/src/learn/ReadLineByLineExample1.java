package learn;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.Connection.Response;  
public class ReadLineByLineExample1  
{  

	
public static void main(String args[])   
{  
	
	List<String>url = new ArrayList<>();
	List<String>Sitemapurl= new ArrayList<>();
	String v = "D:\\Users\\ehopyr1\\Documents\\1.txt";
	String vv = "D:\\Users\\ehopyr1\\Documents\\2.txt";
	url = getUrls(v);
	Sitemapurl = getSitemapUrls(vv);
	for(String p : Sitemapurl) {
		//System.out.println("S map <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+p);
		try {
			String ggg =getParentPage(p);
			
			for(String pp : url) {
				//System.out.println("link from url >> "+pp);
				if (ggg.contains(pp)) {
					System.out.println("The Page>> "+p+"Contains the link >> "+pp);
				}
				}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}





//System.out.println("a is >>"+a.toString());
}

private static List<String> getSitemapUrls(String v) {
	// TODO Auto-generated method stub
	List<String>n = new ArrayList<>();
	try  
	{  
	File file=new File(v);    //creates a new file instance  
	FileReader fr=new FileReader(file);   //reads the file  
	BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream  
	StringBuffer sb=new StringBuffer();    //constructs a string buffer with no characters  
	String line;  
	while((line=br.readLine())!=null)  
	{  
	sb.append(line); 
	n.add(line);
	
	sb.append("\n");     //line feed   
	}  
	fr.close();    //closes the stream and release the resources  
	//System.out.println("Contents of File: ");  
	//System.out.println(sb.toString());

	}  
	catch(IOException ex)  
	{  
	ex.printStackTrace();  
	} 
	return n;
}

private static List<String> getUrls(String v) {
	// TODO Auto-generated method stub
	List<String>a = new ArrayList<>();
	List<String>b = new ArrayList<>();
	List<String>c = new ArrayList<>();
	List<String>d = new ArrayList<>();
	List<String>e = new ArrayList<>();
	List<String>f = new ArrayList<>();
	try  
	{  
	File file=new File(v);    //creates a new file instance  
	FileReader fr=new FileReader(file);   //reads the file  
	BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream  
	StringBuffer sb=new StringBuffer();    //constructs a string buffer with no characters  
	String line;  
	while((line=br.readLine())!=null)  
	{  
	sb.append(line); 
	System.out.println("Contents of File: "+line);
	if (line.contains("publication.html")) {
		a.add(line);
		String [] linee = line.split("https://www.deere.de/");
		f.add(linee[1].replaceFirst("de/", "/"));
	}
	if (line.contains("assets/publications/index.html")) {
		b.add(line);
		String [] linee = line.split("https://www.deere.de/");
		f.add(linee[1].replaceFirst("de/", "/"));
		
	}
	if (line.contains(".pdf")) {
	c.add(line);
	String [] linee = line.split("https://www.deere.de/");
	f.add(linee[1].replaceFirst("de/", "/"));
	}
	if (line.contains("/search/")) {
	d.add(line);
	}
	if (line.contains("/blog/")) {
	e.add(line);
	}
	sb.append("\n");     //line feed   
	}  
	fr.close();    //closes the stream and release the resources  
	//System.out.println("Contents of File: ");  
	//System.out.println(sb.toString());

	}  
	catch(IOException ex)  
	{  
	ex.printStackTrace();  
	} 
	System.out.println("Size of a >>"+a.size());
	System.out.println("Size of b >>"+b.size());
	System.out.println("Size of c >>"+c.size());
	System.out.println("Size of d >>"+d.size());
	System.out.println("Size of e >>"+e.size());
	return f;
}

private static String getParentPage(String j) throws IOException {
	// TODO Auto-generated method stub
	Response response = null;
	response = Jsoup.connect(j).userAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.21 (KHTML, like Gecko) Chrome/19.0.1042.0 Safari/535.21").timeout(30000).execute();
	int statusCode = response.statusCode();
	//System.out.println("Status code :="+statusCode);
	String jj = new String();

	if(statusCode == 200)
	{
		org.jsoup.nodes.Document document = Jsoup.connect(j).get();
		
		//System.out.println("For URL>> "+j+" Status Code is >>> "+statusCode);
		//String categoryPath = document.getElementsByAttributeValueContaining("name", "category-path").toString();
	    //String productPath = document.getElementsByAttributeValueContaining("name", "product-path").toString();
	    
	   
	   /* 
	    if(!categoryPath.isEmpty()) {
	    	categoryPath =getMetaTag(document,"category-path");
	    	TeamsitePage =categoryPath;
	    	 sitemapPageObject.setTeamsitePage(categoryPath);
	    	 
	    	// System.out.println("productPath"+categoryPath);
	    }
	    if(!productPath.isEmpty()) {
	    	productPath=getMetaTag(document,"product-path");
	    	TeamsitePage =productPath;
	    	//System.out.println("productPath"+productPath);
	    	sitemapPageObject.setTeamsitePage(productPath);
	    }
	    */
		jj = document.html().toString();
	}
		else{
			jj ="";	
			if(statusCode !=200) {
				System.out.println("For URL>> "+j+" Status Code is >>> "+statusCode);
				
			}
	
}  
return jj;
}  
}
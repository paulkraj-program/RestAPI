package learn;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mysql.jdbc.PreparedStatement;  

public class MysqlCon{  
	
	public static void main(String args[]){  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://teamsite16rdsd.marketing-devl.us.i06.c01.johndeerecloud.com:3306/tsdb_cat","tsdbuser","ddHF8LL5DFN7qTry");  
		//here sonoo is database name, root is username and password  
		//Statement stmt=con.createStatement();  
		//ResultSet rs=stmt.executeQuery("select * from acl_entries");  
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Map<String,String> mp= new LinkedHashMap<>();
		List<String> result= new ArrayList<>();
		String retrieveQuery = "select * from <TABLE_NAME> where model = ? and Value != 'no' and subcategory not in ('Model Series','SKU','Model Number')";
		retrieveQuery = retrieveQuery.replace("<TABLE_NAME>", "largetractor_product_information");
		String subCat = "";
		String cat = "";
		String value = "";
		String filter= "";
		try {
			stmt = (PreparedStatement) con.prepareStatement(retrieveQuery);
			stmt.setString(1, "9570RT");
			
			System.out.println("[retrieveConfigAttributes] final query is: " + retrieveQuery);
			rs = stmt.executeQuery();

			System.out.println("[retrieveConfigAttributes] query executed");

			while (rs.next()) {
				
				subCat = rs.getString("subcategory");
				cat = rs.getString("category");
				value = rs.getString("value");
				filter = rs.getString("filter");
				
				Pattern pattern = Pattern.compile("\\((.*?)\\)");
			    Matcher matcher = pattern.matcher(subCat);

			        while(matcher.find()) {
			        	subCat = matcher.group(1);
			            
			        }
			    subCat = subCat.replaceAll("(^ )|( $)", "");
			    if(cat.contains("|")) {
			    	String[] categoryFilterArray =cat.split("\\|");
					cat = categoryFilterArray[1];
			    }
			    
			   if(filter.equalsIgnoreCase("radio") ||filter.equalsIgnoreCase("multi-checkbox")) {
			    	if(mp.containsKey(cat)) {
			    		String a = mp.get(cat);
			    		a = a + "|" + subCat;
			    		mp.put(cat, a);
			    	}else {
			    		mp.put(cat, subCat);
			    	}
			    }
			    if(filter.equalsIgnoreCase("range")) {
			    	
			    	mp.put(subCat,value.replace(".0",""));
			    }
			    
			    
			    
			    System.out.println("SubCategory Selected is  >>"+subCat);
				//mp.put(subCat,rs.getString("Min") + "|" + rs.getString("Max"));
			}
			System.out.println("map returned is > "+mp.toString());
		} catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			System.out.println("Closing the connection");
			con.close();
		}
		
	
	
		}catch(Exception e)
		{ 
			System.out.println(e);
		}  
	}  
}  



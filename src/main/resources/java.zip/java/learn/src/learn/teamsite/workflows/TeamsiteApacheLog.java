package learn.teamsite.workflows;

public class TeamsiteApacheLog extends Teamsitelogs {
	String name ="apache_log";
	String logLocation="/opentext/TeamSite/local/logs/iwui";
	String[] patternSet = {"error-\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])-00_00_00.log","access-\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])-00_00_00.log","content_center.log.([0-9]|[10]|[0-9][0-9])"};
	public void executeCleanup() {
		// TODO Auto-generated method stub
		
	}

}
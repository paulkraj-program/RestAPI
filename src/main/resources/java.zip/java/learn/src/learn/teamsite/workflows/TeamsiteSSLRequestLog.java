package learn.teamsite.workflows;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TeamsiteSSLRequestLog extends Teamsitelogs {
	String name ="ssl_request";
	String logLocation="/opentext/ot-logs/iwui";
	String[] patternSet = {"ssl_transfer-\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])-00_00_00.log","ssl_request-\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])-00_00_00.log","ssl_error-\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])-00_00_00.log"};
	public void executeCleanup() {
		// TODO Auto-generated method stub
		
	}

}
 

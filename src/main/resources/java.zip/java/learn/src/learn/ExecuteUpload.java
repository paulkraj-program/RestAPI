package learn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class ExecuteUpload {
	
	public static void main(String [] args)  {
		
		Connection con = null;
		Boolean executeData=false;
		Boolean createTabel=false;
		String pd ="tractortest_category";
		String pdInfo = "tractortest_product_information";
		String pdFltWzd = "tractortest_product_filterwizard";
		//File excelFile = new File("C:\\Users\\ehopyr1\\OneDrive-Deere&Co\\OneDrive - Deere & Co\\Documents\\Products\\Gator_PST_Data30Aug2019.xlsx");
		File excelFile = new File("C:\\Users\\ehopyr1\\Downloads\\Tractor.xlsx");
		
		FileInputStream fis;
		
		/*String sql = "CREATE TABLE IF NOT EXISTS REGISTRATION " +
                "(id INTEGER not NULL, " +
                " first VARCHAR(255), " + 
                " last VARCHAR(255), " + 
                " age INTEGER, " + 
                " PRIMARY KEY ( id ))";*/
		StringBuilder sql = new StringBuilder("CREATE TABLE IF NOT EXISTS "+pd);
        sql.append("(model_series VARCHAR(255), ");
        sql.append(" SKU VARCHAR(255), "); 
        sql.append(" model VARCHAR(255) not NULL, "); 
        sql.append(" PRIMARY KEY ( Model ))");
        
        StringBuilder pdInfoSql = new StringBuilder("CREATE TABLE IF NOT EXISTS "+pdInfo);
        pdInfoSql.append("(model_series VARCHAR(255), ");
        pdInfoSql.append(" SKU VARCHAR(255), "); 
        pdInfoSql.append(" model VARCHAR(255) not NULL, "); 
        pdInfoSql.append(" category VARCHAR(255) not NULL, ");
        pdInfoSql.append(" subcategory VARCHAR(255) not NULL, ");
        pdInfoSql.append(" filter VARCHAR(255) not NULL, ");
        pdInfoSql.append(" value VARCHAR(255) not NULL)");
        
        StringBuilder pdFltWzdSql = new StringBuilder("CREATE TABLE IF NOT EXISTS "+pdFltWzd);
        pdFltWzdSql.append("(id int(11)  AUTO_INCREMENT primary key not NULL,");
        pdFltWzdSql.append(" category VARCHAR(255) not NULL)");
       
        
        
        System.out.println("SQL Builder >>>"+sql.toString());
        
	
		try {
			//con = DriverManager.getConnection("jdbc:mysql://teamsite16rdsd.marketing-devl.us.i06.c01.johndeerecloud.com:3306/tsdb_cat","tsdbuser","ddHF8LL5DFN7qTry");
			con = DriverManager.getConnection("jdbc:mysql://teamsite16rds.marketing-qual.us.i06.c01.johndeerecloud.com:3306/tsdb_cat","tsdbuser","jkGW0KE3QBQ7dPdY");
			Statement stmt = (Statement) con.createStatement();
			DatabaseMetaData dbm = (DatabaseMetaData) con.getMetaData();
			ResultSet tables = dbm.getTables(null, null, pd , null);
			ResultSet pfInfotable = dbm.getTables(null, null, pdInfo , null);
			ResultSet pdFltWzdtable = dbm.getTables(null, null, pdFltWzd , null);
			System.out.println("<<<<<<<<<< Executing the Upload >>>>>>>>>>>");
			if (tables.next()) {
				  System.out.println("Table exits");
				 stmt.executeUpdate("DELETE FROM   "+pd);
				  
				}
				else {
					System.out.println("Table doesn't exits");
					
			        stmt.executeUpdate(sql.toString());
				}
			if (pfInfotable.next()) {
				  System.out.println("Table exits");
				  stmt.executeUpdate("DELETE FROM   "+pdInfo);
				  
				}
				else {
					System.out.println("Creating the Table "+pdInfoSql.toString());
					System.out.println("Table pdInfo doesn't exits");
					
			        stmt.executeUpdate(pdInfoSql.toString());
				}
			if (pdFltWzdtable.next()) {
				  System.out.println("Table exits");
				 stmt.executeUpdate("DELETE FROM   "+pdFltWzd);
				  
				}
				else {
					System.out.println("Table doesn't exits");
					
			        stmt.executeUpdate(pdFltWzdSql.toString());
				}
			
			buildProductsTable(con,excelFile,pd);
			buildProductsInformationTable(con,excelFile,pdInfo,pdFltWzd);
		} catch (SQLException e) {
           e.printStackTrace();
		} catch (IOException e) {
           e.printStackTrace();
		} 
		
       finally {
		
		
		try {
			if(con != null) {
			con.close();
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
       }

		}
	@SuppressWarnings("unchecked")
	private static void buildProductsInformationTable(Connection con, File excelFile, String pdInfo,String pdFltWzd) throws IOException, SQLException {

		XSSFWorkbook workBook;
		Map<String,String> map=new LinkedHashMap<>();
		Map<String,String> mdyMap=new LinkedHashMap<>();
		Map<String,String> mdyMapHeaders = UploadData.getCategoryHeaders(excelFile,0);
		Map<String,String> filterMap = UploadData.getCategoryHeaders(excelFile,1);
		LinkedHashSet<String> filterLinkedSet = new LinkedHashSet<>();
		
		if (excelFile.exists()) {
			
			
			FileInputStream fis = new FileInputStream(excelFile);

		   workBook = new XSSFWorkbook(fis);
		   XSSFSheet sheet = workBook.getSheetAt(0);
           XSSFRow r = sheet.getRow(0);
		   int colCount = r.getLastCellNum();
		   int rowCount = sheet.getLastRowNum() +1;
		   
		   String category = "";
		   String filter = "";
		   String subcategory = "";
		   String categoryCheck = "";
		   String cellValueString = "";
		   System.out.println("Row Count is "+rowCount);
		   System.out.println("Col Count is "+colCount);
		    
			    for (Row row : sheet) {
			    	
				    	if(row.getRowNum() == 2) {
				    		System.out.println("Row Number 2 condition  is "+row.getRowNum());
					        for (Cell cell : row) {
					        	
						            
						            	//map.put(cell.getAddress().toString(), cell.getStringCellValue());
					        	System.out.println("");
					        	System.out.println("cell.getAddress()"+cell.getAddress().toString());
					        	System.out.println("cell Type is "+cell.getCellType());
					        	System.out.println("cell address Type is "+cell.getAddress().toString());
					        	
					        	if(cell.getCellType() == 1) {
						            	mdyMap.put(cell.getAddress().toString().replaceAll("[0123456789]",""), cell.getStringCellValue().replaceAll("[\\n]", ""));
					        	}
					        	if(cell.getCellType() == 0) {
					        		String val = NumberToTextConverter.toText(cell.getNumericCellValue());
					            	mdyMap.put(cell.getAddress().toString().replaceAll("[0123456789]",""), val.replaceAll("[\\n]", ""));
				        	}
					        }
				    	}
				    	if(row.getRowNum() > 2) {
				    	System.out.println("Row Number is "+row.getRowNum());
				    	for(int i =0; i<colCount;i++) {
				    	 Cell cellValue = row.getCell(i);
				    	 String cellAddress = row.getCell(i).getAddress().toString();
				    	// String cellAddressForHeader = cellAddress.substring(0, cellAddress.length() - 1);
				    	 String cellAddressForHeader = cellAddress.replaceAll("[0123456789]","");
				    	 System.out.println(row.getCell(0)+">>>"+row.getCell(1)+">>>"+row.getCell(2)+">>>"+row.getRowNum()+">>>"+mdyMap.get(cellAddressForHeader)+">>>"+cellAddress+">>>"+cellValue);
				    	 
				    	 categoryCheck = mdyMap.get(cellAddressForHeader).toString();
				    	// System.out.println("categoryCheck >>"+categoryCheck);
				    	 if(categoryCheck.contains("|")) {
				    		 
				    		 System.out.println("categoryCheck >>"+categoryCheck+" contains |");
				    		// String[] categoryValues= categoryCheck.split("\\|");
				    		// System.out.println("categoryValues from the array are >>"+categoryValues.length);
				    		 //category = categoryValues[0];
				    		 //subcategory = categoryValues[1];
				    		 category = mdyMapHeaders.get(cellAddressForHeader);
				    		 subcategory=mdyMap.get(cellAddressForHeader);
				    		 filter=filterMap.get(cellAddressForHeader);
				    		 //System.out.println("category is >>"+category);
				    		// System.out.println("subcategory >>"+subcategory);
				    	 }
				    	 else {
				    		 category = mdyMapHeaders.get(cellAddressForHeader);
				    		 subcategory=mdyMap.get(cellAddressForHeader);
				    		 filter=filterMap.get(cellAddressForHeader);
				    		 /*System.out.println("categoryCheck >>"+categoryCheck+" doesnt contains |");
				    		 System.out.println("category is >>"+category);
				    		 System.out.println("subcategory >>"+subcategory);*/
				    	 }
				    	 cellValueString = cellValue.toString();
				    	 if(cellValue.toString().isEmpty() || cellValue.toString().equalsIgnoreCase("") ) {
				    		 cellValueString = "No";
				    	 }
				    	 else if(cellValue.toString().equalsIgnoreCase("x")) {
				    		 cellValueString ="Yes";
				    	 }
				    	   String modelseries =quote(row.getCell(0).toString());
						   String sku=quote(row.getCell(1).toString());
						   String model=quote(row.getCell(2).toString()); 
						   
						   if(!category.contains("|") && !filter.equalsIgnoreCase("range")) {
							   if(category.contains("(")) {
								   String secondvalue = category.substring(category.indexOf("(")+1,category.indexOf(")"));
								   String firstvalue = category.replaceAll("\\s*\\([^\\)]*\\)\\s*", " ");
								   category=firstvalue.trim() + "|" + secondvalue;
							   }
						   }
						   
						   
						   
						   
						  
						   category =quote(category);
						   
						   filterLinkedSet.add(category);
						   subcategory =quote(subcategory);
						   cellValueString =quote(cellValueString);
						   filter=quote(filter);
				    	 String pdInfosql = "INSERT INTO " + pdInfo +" VALUES ("+modelseries+","+sku+","+model+","+category+","+subcategory+","+filter.toLowerCase()+","+cellValueString+")";
				    	 System.out.println(">>>"+pdInfosql);
				    	 Statement  stmt = (Statement) con.createStatement();
				    	 stmt.executeUpdate(pdInfosql);
				    	}
				    	}
			    	
					    
					}
		    }
		 if(!filterLinkedSet.isEmpty()) {
			 Iterator<String> itr = filterLinkedSet.iterator();
		        while(itr.hasNext()){
		        	
		        	String itrNExtValue = itr.next();
		        	//System.out.println("=>"+itrNExtValue);
		        	if(!itrNExtValue.equalsIgnoreCase("'SKU'") && !itrNExtValue.equalsIgnoreCase("'Model Series'") && !itrNExtValue.equalsIgnoreCase("'Model Number'")) {
		        	 String pdFltWzdSql = "INSERT INTO " + pdFltWzd +"(category) VALUES ("+itrNExtValue+")";
		        	 System.out.println(pdFltWzdSql);
			    	Statement  stmt = (Statement) con.createStatement();
			    	stmt.executeUpdate(pdFltWzdSql);
		        }
		        }
		 }
		
		
			    for (Map.Entry<String, String> entry : map.entrySet()) {
		    		//System.out.println(entry.getKey() + "->" + entry.getValue().toString().replaceAll("[\\n]", ""));
				    
				    
				    }
			    for (Map.Entry<String, String> mdyMapentry : mdyMap.entrySet()) {
		    		//System.out.println(mdyMapentry.getKey() + "->" + mdyMapentry.getValue());
				    
				    
				    }
		    
	}
	public static String quote(String s) {
	    return new StringBuilder()
	        .append('\'')
	        .append(s)
	        .append('\'')
	        .toString();
	}
	private static void buildProductsTable(Connection con, File excelFile, String pd) throws IOException, SQLException {

		
		if (excelFile.exists()) {
			Statement  stmt = (Statement) con.createStatement();
		      
			FileInputStream fisProducts = new FileInputStream(excelFile);

			XSSFWorkbook productWorkBook = new XSSFWorkbook(fisProducts);
		    XSSFSheet productSheet = productWorkBook.getSheetAt(0);
            XSSFRow product = productSheet.getRow(0);
		   //int colCount = product.getLastCellNum();
		   //int rowCount = productSheet.getLastRowNum() +1;
		   for (Row productRow : productSheet) {
			   if(productRow.getRowNum() > 2) {
				   
					   //System.out.println(productRow.getRowNum()+">>>>"+productRow.getCell(0)+">>>"+productRow.getCell(1)+">>>"+productRow.getCell(2));
					   
					   String model_series =quote(productRow.getCell(0).toString());
					   String sku=quote(productRow.getCell(1).toString());
					   String model=quote(productRow.getCell(2).toString());
					      
					   String sql = "INSERT INTO " + pd +" VALUES ("+model_series+","+sku+","+model+")";
					   //System.out.println(">>"+sql);
					   String queryCheck = "SELECT * from "+pd+" WHERE model = ?";
			            PreparedStatement st = (PreparedStatement) con.prepareStatement(queryCheck);
			            st.setString(1, productRow.getCell(2).toString());
			            ResultSet rs = st.executeQuery();
			            if(rs.next()) {
			                System.out.println("Model is "+rs.getString("model"));
			                
			            }else{
			            
					       stmt.executeUpdate(sql);
			            }
			   }
		   }
		   
		}
		
	}

	public static CellRangeAddress getMergedRegion(Cell cell) {
	    org.apache.poi.ss.usermodel.Sheet sheet = cell.getSheet();
	    for (CellRangeAddress range : ((XSSFSheet) sheet).getMergedRegions()) {
	        if (range.isInRange(cell.getRowIndex(), cell.getColumnIndex())) {
	            return range;
	        }
	    }
	    return null;
	}
}

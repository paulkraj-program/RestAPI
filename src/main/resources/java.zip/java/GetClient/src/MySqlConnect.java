


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;



public class MySqlConnect {
	private MySqlConnect() {
	    throw new IllegalStateException("Connection Utility class");
	  }

	public static Properties getProperties(String fileName) {
		  
	      Properties prop = null;
	      FileInputStream fis = null;
	      try {
	    	  fis = new FileInputStream(fileName);
	          prop = new Properties();
	          prop.load(fis);
	          fis.close();
		       } catch(FileNotFoundException fnfe) {
		          fnfe.printStackTrace();
		       } catch(IOException ioe) {
		          ioe.printStackTrace();
		       } 
	      finally {
	    	  if(fis !=null) {
	    		  try {
					fis.close();
				} catch (IOException e) {
                   e.printStackTrace();
				}
	    	  }
	      }
	       return prop;
	  }
	public static Connection getConnection(Properties prop) {
        
		Connection con = null;
		String dbUrl = prop.getProperty("DBURL");
		String dbUser = prop.getProperty("DBUSER");
		String cred = prop.getProperty("DBCRED");
		try {
			 con = DriverManager.getConnection(dbUrl,dbUser,cred); 
			} catch (Exception e) {
				e.printStackTrace();
           }
		return con;

	}
	
}

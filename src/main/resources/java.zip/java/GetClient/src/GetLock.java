import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSBranch;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSWorkflow;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class GetLock {
	public static void main(String[] args) throws Exception {
		 List<String>  b = new ArrayList<String>();
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
	    CSClient client = TeamsiteConnection.getCSClient(prop);
	    Date currentDate = new Date();
	    System.out.println("Current Date is "+currentDate);
		CSWorkflow jobs[] = client.getWorkflowEngine().getWorkflowsByQuery("<wfquery><active/></wfquery>");
		for(CSWorkflow job:jobs) {
	       CSTask[] t =job.getTasks();
	       System.out.println(">>>>>>>>>>>>>>>>>>>>>"+job.getId());
	       for(CSTask cstask:t) {
	    	  //System.out.println("cstask.getName() >>"+cstask.getName());
	    	   if(cstask.getName().equalsIgnoreCase("DummyTask")) {
	    		   
	    		  
	    		   //Attach Page Dependencies
	    		   System.out.println(">>>cstask.getTimeoutType()  "+cstask.getTimeoutType());
	    		   System.out.println(">>>cstask.getAbsoluteTimeout()  "+cstask.getAbsoluteTimeout());
	    		   System.out.println(">>>cstask.getAbsoluteTimeout()  "+job.getOwner().getDisplayName());
	    		   
	    		   if(cstask.getAbsoluteTimeout() != null) {
	    			  
	    			  getFiles(job,b,client);
	    		   }
	    		   
	    	   }
	    	   
	       }
			
		}
	
		System.out.println(b);
	
	  }

	private static List<String> getFiles(CSWorkflow job, List<String> b, CSClient client) {
		// TODO Auto-generated method stub
		
		 try {
			CSTask[] hh =job.getTasks();
			for(CSTask gg:hh) {
				
				if(gg.getName().equalsIgnoreCase("Attach Page Dependencies")) {
					CSWorkarea wa  = client.getWorkarea(gg.getArea().getVPath(), false);
					System.out.println(wa.getBranch().getParentBranch().getName());
					System.out.println(wa.getBranch().getName());
					
					CSAreaRelativePath[] tt =gg.getFiles();
					for(CSAreaRelativePath y:tt) {
				    b.add(gg.getArea().getUAI()+"/"+y.getParentPath()+"/"+y.getName());
				    
				    CSFile csFile = client.getFile(new CSVPath(gg.getArea().getUAI()+"/"+y.getParentPath()+"/"+y.getName()));
				   
				    if(y.getParentPath().toString().contains("templatedata/") || y.getName().contains(".page") ) {
				    	 System.out.println("csFile >>>"+ csFile.getUAI());
				    }
				    else {
				    	System.out.println("Not cleare with basic >>>>>>>>>>>>>>>");
				    	
				    }
					}
				}
			}
			
		} catch (CSAuthorizationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CSRemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CSObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CSExpiredSessionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
	}

}

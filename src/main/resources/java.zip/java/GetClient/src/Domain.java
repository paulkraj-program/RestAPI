import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class Domain {
	
	private static final String deereSiteBranch ="/iwmnt/default/main/deere/";
	private static final String deereSiteWorkarea ="/WORKAREA/shared/sites/deere/default.site";

	public static void main(String[] args) {
		
		String r = "us-en/index";
		
		String deereSiteURL = pageSiteURL(r);
		
	}
	private static String pageSiteURL(String pPageName) {
		String siteURL="";
		if(pPageName.contains("/")) {
			String[] pagePath = pPageName.split("/");
			 if(pagePath.length > 0)
				{
				  String combinedCCLC = pagePath[0];
				  System.out.println("combinedCCLC >>> "+combinedCCLC);
				  if(combinedCCLC.contains("-")) {
						String[] arrayCCLC = combinedCCLC.split("-");
						if(arrayCCLC.length> 0)
						{
							String countryCode = arrayCCLC[0];
							String languageCode =arrayCCLC[1];
							//String sitePath = deereSiteBranch+countryCode.toLowerCase()+File.separator+languageCode.toLowerCase()+deereSiteWorkarea;
							String sitePath ="C:\\default.site";
							System.out.println("sitePath >> "+sitePath);
							siteURL = getSiteDomainURL(sitePath);
						}
					}
				
			}
			
		}
		
		return siteURL;
	}

	private static String getSiteDomainURL(String sitePath) {
		String URLDomain="";
		
		File f = new File(sitePath);
		if (f.exists()) {
			
			URLDomain = URLDomain + "| File Exits";
			
			try {
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
				dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				org.w3c.dom.Document doc = dBuilder.parse(f);
				
				
				XPath xPath = XPathFactory.newInstance().newXPath();
				Node serverNode = (Node) xPath.evaluate("/Site/URL/Server", doc, XPathConstants.NODE);
				Node domainNode = (Node) xPath.evaluate("/Site/URL/Domain", doc, XPathConstants.NODE);
				
			    String servername = serverNode.getTextContent();
			    String domaiName = domainNode.getTextContent();
			    System.out.println("encoing" + doc.getXmlEncoding());
			    System.out.println("servername "+servername);
			    System.out.println("domaiName "+domaiName);
			
			
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (XPathExpressionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			
		
		}
			
			
		
		
		
		return URLDomain;
	}
}

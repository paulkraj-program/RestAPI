
public class Name {

	public static void main(String[] args) {
		
		StandardBean sb = new StandardBean();
		
		sb.setFname("Paul");
		sb.setLname("Raj");
		
		System.out.println("name "+sb.getName());
	}
}

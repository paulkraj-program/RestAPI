
public class StandardBean {

	String fname;
    String lname;
	String name;
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getName() {
		name = fname+lname;
		return name;
	}
	public void setName(String name) {
		
		this.name = name;
	}
	
	
}

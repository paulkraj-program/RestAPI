
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.workflow.CSWorkflow;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class GetWf {
	public static void main(String[] args) throws Exception {
		List<String> v = new ArrayList<>();
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
	    CSClient client = TeamsiteConnection.getCSClient(prop);
	    Date currentDate = new Date();
	    System.out.println("Current Date is "+currentDate);
		CSWorkflow jobs[] = client.getWorkflowEngine().getWorkflowsByQuery("<wfquery><active/></wfquery>");
		/*for(CSWorkflow job:jobs) {
			Date jobDate = job.getActivationDate();
			System.out.println("==================================");
			System.out.println("Wf id is "+job.getId()+" "+job.getDescription()+" wf Date is "+currentDate);
			long diff = currentDate.getTime() - jobDate.getTime();
			long diffDays = diff / (24 * 60 * 60 * 1000);
			System.out.println("Days old is " +diffDays);
			if(diffDays >100) {
				job.terminate();
			}
			
		}*/
		
		//https://dce-vsnts-16-d.tal.deere.com/iw-cc/command/iw.ccpro.task_details?taskid=54301059
		String a = "https://dce-vsnts-16-d.tal.deere.com/iw-cc/command/iw.ccpro.task_details?taskid=";
		for(CSWorkflow job:jobs) {
			
			String h = a + job.getId();
			v.add(h);
			
			
		}
	
		
		System.out.println("URL >>> "+v);
		
	   
	  }

}

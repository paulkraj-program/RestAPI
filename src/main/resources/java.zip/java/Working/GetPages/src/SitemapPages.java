
public class SitemapPages {


	private String sitemapUrl;
	
	private String convertedSitemapUrl;
    private String teamsitePage;
	private String locale;
    private String containsFolder;
    private Boolean containsIndexPage = Boolean.FALSE;
	private int httpStatusCode =0;
	private Boolean isLive = Boolean.FALSE;
	private Boolean containsIndexHTML = Boolean.FALSE;
	private String keyTranslatedSiteMapPagePath;
	private String keySiteMapPagePath;
	private String workAreaVPath;
	
	
	public String getWorkAreaVPath() {
		return workAreaVPath;
	}
	public void setWorkAreaVPath(String workAreaVPath) {
		this.workAreaVPath = workAreaVPath;
	}
	public Boolean getContainsIndexPage() {
		return containsIndexPage;
	}
	public void setContainsIndexPage(Boolean containsIndexPage) {
		this.containsIndexPage = containsIndexPage;
	}
	public String getKeyTranslatedSiteMapPagePath() {
		return keyTranslatedSiteMapPagePath;
	}
	public void setKeyTranslatedSiteMapPagePath(String keyTranslatedSiteMapPagePath) {
		this.keyTranslatedSiteMapPagePath = keyTranslatedSiteMapPagePath;
	}
	public Boolean getContainsIndexHTML() {
		return containsIndexHTML;
	}
	public void setContainsIndexHTML(Boolean containsIndexHTML) {
		this.containsIndexHTML = containsIndexHTML;
	}
	

	public String getKeySiteMapPagePath() {
		return keySiteMapPagePath;
	}
	public void setKeySiteMapPagePath(String keySiteMapPagePath) {
		this.keySiteMapPagePath = keySiteMapPagePath;
	}
	public Boolean getIsLive() {
		return isLive;
	}
	public void setIsLive(Boolean isLive) {
		this.isLive = isLive;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getConvertedSitemapUrl() {
		return convertedSitemapUrl;
	}
	public void setConvertedSitemapUrl(String convertedSitemapUrl) {
		this.convertedSitemapUrl = convertedSitemapUrl;
	}
	public String getSitemapUrl() {
		return sitemapUrl;
	}
	public void setSitemapUrl(String sitemapUrl) {
		this.sitemapUrl = sitemapUrl;
	}
	public String getTeamsitePage() {
		return teamsitePage;
	}
	public void setTeamsitePage(String teamsitePage) {
		this.teamsitePage = teamsitePage;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getContainsFolder() {
		return containsFolder;
	}
	public void setContainsFolder(String containsFolder) {
		this.containsFolder = containsFolder;
	}

	@Override
	public String toString() {
		return "SitemapPages [sitemapUrl=" + sitemapUrl + ", convertedSitemapUrl=" + convertedSitemapUrl
				+ ", teamsitePage=" + teamsitePage + ", locale=" + locale + ", containsFolder=" + containsFolder
				+ ", containsIndexPage=" + containsIndexPage + ", httpStatusCode=" + httpStatusCode + ", isLive="
				+ isLive + ", containsIndexHTML=" + containsIndexHTML + ", keyTranslatedSiteMapPagePath="
				+ keyTranslatedSiteMapPagePath + ", keySiteMapPagePath=" + keySiteMapPagePath + ", workAreaVPath="
				+ workAreaVPath + "]";
	}





	
	

}

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.interwoven.cssdk.access.CSAuthenticationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSHole;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSWorkflow;
import com.interwoven.cssdk.workflow.CSWorkflowEngine;



public class GetWorkflow {
	
	static List<CSDir> queue ;
	public static void main(String[] args) {
		List<CSSimpleFile> SiteFiles ;
		
		Properties prop = new Properties();
       
			try {
				
				SiteFiles = new ArrayList<CSSimpleFile>();
				SiteFiles.clear();
				prop.load(new FileInputStream(
				        new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
				CSClient client = Connection.getTeamSiteCSClient(prop);
				String workareaPath = "/default/main/deere/us/en/WORKAREA/shared/templatedata/deere";
				CSFile filesinSites = client.getFile(new CSVPath(workareaPath));
				
				if (CSDir.KIND == filesinSites.getKind()) {
			           SiteFiles.addAll(getAllFilesInDirectory((CSDir) filesinSites));
			    	}
				
				for(CSSimpleFile SiteFile: SiteFiles)  {
				/*
				 * String user = SiteFile.getOwner().getName();
				 * System.out.println("File Name is >>>"+SiteFile.getVPath().toString()+">>>>"+
				 * user);
				 */
					
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSAuthenticationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSRemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	private static List<CSSimpleFile> getAllFilesInDirectory(CSDir directory)  {
		// TODO Auto-generated method stub
		List<filePermission> list=new ArrayList<filePermission>();
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFSheet sheet = workbook.createSheet("sheet1");
		
		
		List<CSSimpleFile> paths = new ArrayList<CSSimpleFile>();
		
		queue = new ArrayList<CSDir>();
		paths.clear();
		queue.clear();
		queue.add(directory);
		while (!queue.isEmpty()) {
			CSDir curr = queue.remove(0);
			
			
			try {
				for (CSNode child : curr.getChildren()) {
					filePermission fp = new filePermission();
					filePermission deletedfp = new filePermission();
					if (CSDir.KIND == child.getKind()) {
						queue.add((CSDir) child);
						
					}
					else if(child.getKind() == 3) {
						CSHole cshole = (CSHole) child;
						String d = new String();
						String fileHolePathc = cshole.getVPath().getAreaRelativePath().toString();
						String fileHoleID = cshole.getLastModifier().getName().toString() ;
						System.out.println("Processing for >>>>>"+fileHolePathc);
						if(cshole.getAttributeModificationDate().toString()!=null) {
							 d = cshole.getAttributeModificationDate().toString();
						}
                         System.out.println(fileHolePathc+">>>"+">>>>>"+fileHoleID+">>>"+d);
						deletedfp.setFile(fileHolePathc);
						deletedfp.setOwner(fileHoleID); 
						list.add(deletedfp);
						
						
					}
					else if(CSSimpleFile.KIND == child.getKind() && child.getVPath().toString().contains("/templatedata/")) {
						
					/*
						if(child.getVPath().getAreaRelativePath().toString().contains("/data/")) {
							String user = child.getOwner().getName();
							System.out.println("File Name is >>>"+child.getVPath().getAreaRelativePath());
							
							  fp.setFile(child.getVPath().getAreaRelativePath().toString());
							  fp.setOwner(user); 
							  list.add(fp);
							 
                             paths.add((CSSimpleFile) child);
						
						System.out.println(paths.size());
						}
						*/
						
					     
					}
					else {}
				}
				
				Row frow = sheet.createRow(0); 
				Cell cell = frow.createCell(0);
				 cell.setCellValue("DCR Path"); 
				 cell = frow.createCell(1);
				 cell.setCellValue("Owner");
				 
				 int rownum = 1; 
				 for (filePermission file : list)
				 { 
					 Row row = sheet.createRow(rownum++); 
					 createList(file, row);
				  
				 }
				 
				 FileOutputStream out = new FileOutputStream(new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/Deleted_Files.xlsx")); 
				 // file name with path
				 workbook.write(out); 
				 out.close();
				 
				
			} catch (CSObjectNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSExpiredSessionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return paths;
	}
	private static void createList(filePermission fObject, Row row) // creating cells for each row
	{
	        Cell cell = row.createCell(0);
	        cell.setCellValue(fObject.getFile());
	     
	        cell = row.createCell(1);
	        cell.setCellValue(fObject.getOwner());
	     
	       
	    }

}

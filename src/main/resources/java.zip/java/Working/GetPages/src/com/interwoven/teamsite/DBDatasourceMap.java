package com.interwoven.teamsite;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import com.interwoven.datasource.MapDataSource;
import com.interwoven.datasource.core.DataSourceContext;
import com.interwoven.livesite.common.cssdk.datasource.AbstractDataSource;

public class DBDatasourceMap {

	//private static final Logger LOGGER = Logger.getLogger(DBDatasourceMap.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Map<String,String> mp = new LinkedHashMap<String,String>();
        RetrieveResultSet resultSet = new RetrieveResultSet();
        String requestParam = "";
		String configAttribute="";
		try {
			Map<String, String> mMap  = RetrieveResultSet.retrieveConfigAttributes(requestParam, "GETPRODUCTRANGE");
			System.out.println(mMap.toString());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

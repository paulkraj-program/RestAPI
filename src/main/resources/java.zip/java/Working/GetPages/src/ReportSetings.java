import java.util.List;

public class ReportSetings {

	String locale;
	String branches;
	String sitemapFile;
	String dictionaryFile;
	List<String> Sitemapurls;
	String workareaPath;
	
	public String getWorkareaPath() {
		return workareaPath;
	}
	public void setWorkareaPath(String workareaPath) {
		this.workareaPath = workareaPath;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getBranches() {
		return branches;
	}
	public void setBranches(String branches) {
		this.branches = branches;
	}
	public String getSitemapFile() {
		return sitemapFile;
	}
	public void setSitemapFile(String sitemapFile) {
		this.sitemapFile = sitemapFile;
	}
	public String getDictionaryFile() {
		return dictionaryFile;
	}
	public void setDictionaryFile(String dictionaryFile) {
		this.dictionaryFile = dictionaryFile;
	}
	public List<String> getSitemapurls() {
		return Sitemapurls;
	}
	public void setSitemapurls(List<String> sitemapurls) {
		Sitemapurls = sitemapurls;
	}

	
}

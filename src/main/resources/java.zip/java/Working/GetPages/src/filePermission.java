

public class filePermission {    
    public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	private String file;
    private String owner;
    public filePermission(){
        this.file="";
        this.owner="";
    }
    

    
}


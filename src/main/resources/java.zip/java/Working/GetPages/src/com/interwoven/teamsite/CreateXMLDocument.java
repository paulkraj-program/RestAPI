package com.interwoven.teamsite;

import java.util.List;

import org.dom4j.Document;

public class CreateXMLDocument {

	public Object getConfigAttributesXMLDocument(List<Object> result, String string, String string2, String string3) {
		// TODO Auto-generated method stub
		return null;
	}

	public Document constructXMLDocument(Document document, String string, String string2,
			String[] xpathExpressionOfSingleNode) {
		// TODO Auto-generated method stub
		return null;
	}

}

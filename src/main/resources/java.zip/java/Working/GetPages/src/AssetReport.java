


import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import com.interwoven.cssdk.access.CSAuthorizationException;
import com.interwoven.cssdk.access.CSExpiredSessionException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSObjectNotFoundException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSArea;
import com.interwoven.cssdk.filesys.CSAreaRelativePath;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSNode;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;



public class AssetReport {
	private String transition = "";
    private String transitionComment = "FileList Created Successfully";
    private static List<CSSimpleFile> AttachFiles = new ArrayList<CSSimpleFile>();
    private static List<String> pageList = new ArrayList<String>();
    private static List<String> htmlList = new ArrayList<String>();
    private static List<String> dcrList = new ArrayList<String>();
    private static List<String> imageList = new ArrayList<String>();
    private static List<String> otherList = new ArrayList<String>();
    private static List<CSSimpleFile> SiteFiles = new ArrayList<CSSimpleFile>();
    
    private List<CSAreaRelativePath> AttachFilesRelativePath = new ArrayList<CSAreaRelativePath>();
	private static CSExternalTask CSTask;
	private static CSClient CSClient;
	//private static final transient Logger LOGGER = Logger.getLogger(AssetReport.class);
	
	public static void main(String args[]) throws CSException {
		//CSAreaRelativePath sharedPath = new CSAreaRelativePath("/iwmnt/default/main/deere/us/en/WORKAREA/shared");
		//CSClient.getWorkarea(sharedPath, true);
	//	 CSAreaRelativePath[] relativePath = CSTask.getFiles();
		System.out.println("Initial Size of Page List >>"+pageList.size());
		System.out.println("Initial Size of html List >>"+htmlList.size());
		System.out.println("Initial Size of DCR List >>"+dcrList.size());
		System.out.println("Initial Size of others List >>"+otherList.size());
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
			
			CSClient = Connection.getTeamSiteCSClient(prop);
			
			  String workareaPath = "/default/main/deere/us/en/WORKAREA/shared";
			  CSFile filesinSites = CSClient.getFile(new CSVPath(workareaPath));
			  if (CSDir.KIND == filesinSites.getKind()) {
		           getAllFilesInDirectory((CSDir) filesinSites);
		         }
System.out.println("Size of Page List >>"+pageList.size());
System.out.println("Size of html List >>"+htmlList.size());
System.out.println("Size of DCR List >>"+dcrList.size());
System.out.println("Size of others List >>"+otherList.size());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
   	 private static void getAllFilesInDirectory(CSDir directory) {
         // TODO Auto-generated method stub
         List<CSSimpleFile> paths = new ArrayList<CSSimpleFile>();
         List<CSDir> queue = new ArrayList<CSDir>();
         queue.add(directory);
         while (!queue.isEmpty()) {
                         CSDir curr = queue.remove(0);
                         
                         try {
                                         for (CSNode child : curr.getChildren()) {
                                                         if (CSDir.KIND == child.getKind()) {
                                                                 queue.add((CSDir) child);
                                                         } else if (CSSimpleFile.KIND == child.getKind()) {
                                                        	 System.out.println("Procressing >>>>>>>>>>>>>>"+child.getUAI());
                                                        	if ( child.toString().contains(".page")){
                                                        		//System.out.println("Page is >>>"+child.getUAI().toString());
                                                        		pageList.add(child.getUAI().toString());
                                                        	}
                                                        	else if(child.toString().contains(".html")) {
                                                        		//System.out.println("html is >>>"+child.getUAI().toString());
                                                        		htmlList.add(child.getUAI().toString());
                                                        		
                                                        	}
                                                        	else if (child.toString().contains("/templatedata/")) {
                                                        		//System.out.println("DCR is >>>"+child.getUAI().toString());
                                                        		dcrList.add(child.getUAI().toString());
                                                        	}
                                                        	else {
                                                        		//System.out.println("Others is >>>"+child.getUAI().toString());
                                                        		otherList.add(child.getUAI().toString());
                                                        	}
                                                        	
                                                                        
                                                                         //paths.add((CSSimpleFile) child);
                                               
                                                                         
                                                         }
                                                         else {}
                                         }
                         } catch (CSObjectNotFoundException e) {
                                         // TODO Auto-generated catch block
                                         e.printStackTrace();
                         } catch (CSExpiredSessionException e) {
                                         // TODO Auto-generated catch block
                                         e.printStackTrace();
                         } catch (CSException e) {
                                         // TODO Auto-generated catch block
                                         e.printStackTrace();
                         }
         }
         
        
}

	

	
}

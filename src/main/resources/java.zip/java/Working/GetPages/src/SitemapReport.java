import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.function.Supplier;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.XmlOptions;

import com.interwoven.cssdk.access.CSAuthenticationException;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSRemoteException;
import com.interwoven.cssdk.filesys.CSBranch;
import com.interwoven.cssdk.filesys.CSDir;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.wcm.lscs.Client;





public class SitemapReport {
	private static CSClient client;
	static String htmlFolder = new String();
	static String sitesFolder = new String();
	static Map<String, String> htmlMap = new HashMap<String, String>();
	static Map<String, String> pageMap = new HashMap<String, String>();
	static String iwmnt = "/iwmnt";
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		List<String> Sitemapurls ;
		List<SitemapPages> httpstatusNotVlid;
		List<SitemapPages> teamsitePageNotVlid;
		List<String> pageNotLive ;
		List<SitemapPages> translatedSitemapurls ;
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFSheet sheet = workbook.createSheet("sheet1");
		List<Thread> threadList = new ArrayList<>();
		
		Properties prop = new Properties();
       
      
       
			try {
				ReportSetings settings = new ReportSetings();
				httpstatusNotVlid = new ArrayList<SitemapPages>();
				teamsitePageNotVlid = new ArrayList<SitemapPages>();
				pageNotLive=new ArrayList<>();
				Boolean httpStatus = true;
				prop.load(new FileInputStream(
				        new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
				 client = Connection.getTeamSiteCSClient(prop);
				String workareaPath = "/default/main/deere/us/en/WORKAREA/shared";
				settings.setWorkareaPath(SitemapReport.iwmnt+workareaPath);
				String parentBranch = client.getWorkarea(new CSVPath(workareaPath), false).getBranch().getParentBranch().getName().toString();
				String locale = client.getWorkarea(new CSVPath(workareaPath), false).getBranch().getName().toString();
				settings.setLocale(locale);
		
				System.out.println("Branch is >>>>"+parentBranch+File.separator+locale);
				settings.setBranches(parentBranch+File.separator+locale);
				htmlFolder = SitemapReport.iwmnt+workareaPath+File.separator+"html/deere"+File.separator+parentBranch+File.separator+locale+File.separator+"website";
				sitesFolder =SitemapReport.iwmnt+workareaPath+File.separator+"sites/deere"+File.separator+parentBranch+File.separator+locale+File.separator+"website";
				
				
				Instant start = Instant.now();
				htmlMap = TeamSiteCommonUtils.getFolderMap(htmlFolder);
				pageMap = TeamSiteCommonUtils.getFolderMap(sitesFolder);

				

				
				
				
				
			    //htmlMap = TeamSiteCommonUtils.gethtmlMapbyStream(htmlFolder);
				System.out.println("Size of htmlMap is >>>>>>################"+htmlMap.size());
				System.out.println("Size of pageMap is >>>>>>################"+pageMap.size());
				System.out.println("htmlMap.size() >>>>"+htmlMap.toString());
				Instant end = Instant.now();

				Duration interval = Duration.between(start, end);

				System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    Execution time in seconds: >>>>>>>>>>>>>>>>>>>>>>>>>>" +interval.getSeconds());
				System.out.println("Locale is >>>>>>"+locale);
				String sitemapFile = TeamSiteCommonUtils.getSiteMap(settings);
				settings.setSitemapFile(sitemapFile);
				System.out.println("sitemapFile  is >>>>>>"+sitemapFile);
				if(sitemapFile.isEmpty() || sitemapFile != null || sitemapFile!="") {
					Sitemapurls = new ArrayList<String>();
					Sitemapurls= TeamSiteCommonUtils.getSiteMapUrls(settings);
					settings.setSitemapurls(Sitemapurls);
					System.out.println("Size of Sitemapurls is >>"+Sitemapurls.size());
                    String DictionaryFile = TeamSiteCommonUtils.getSiteDictionary(settings);
                    settings.setDictionaryFile(DictionaryFile);
                    translatedSitemapurls= TeamSiteCommonUtils.getSiteMapUrls(settings,true);
                    
                    //System.out.println("translatedSitemapurls>>"+translatedSitemapurls.toString());
                    System.out.println("Size of translatedSitemapurls is >>"+translatedSitemapurls.size());
                    
                    List<Future<SitemapPages>> SiteMapDetails = TeamSiteCommonUtils.getPageDetails(translatedSitemapurls);
                    
                    System.out.println( "SiteMapDetails.size()   >>>"+SiteMapDetails.size());
                   
                    translatedSitemapurls.clear();
        			for (Future<SitemapPages> f : SiteMapDetails) {
        				try {
        					SitemapPages u = f.get();
        						translatedSitemapurls.add(u);
                            } catch (Exception e) {
        					
        				}
        			}
        			 System.out.println( "StranslatedSitemapurls size after Clear  >>>"+translatedSitemapurls.size());
        			// System.out.println( "SiteMapDetails.size()   >>>"+translatedSitemapurls.toString());
					for (SitemapPages sp :translatedSitemapurls) {
						if(sp.getTeamsitePage()==null) {
							String pagePathFromTeamSite=pageMap.get(sp.getKeyTranslatedSiteMapPagePath());
							if(pagePathFromTeamSite !=null) {
								String[] pagePathFromTeamSiteArray = pagePathFromTeamSite.split(workareaPath);
								sp.setTeamsitePage(pagePathFromTeamSiteArray[1]);
								System.out.println("pagePathFromTeamSite >>>>>"+pagePathFromTeamSiteArray[1]);
								sp.setContainsIndexPage(Boolean.TRUE);
							}
							else {
								sp.setTeamsitePage("No TeamSite Page Found");
								teamsitePageNotVlid.add(sp);
							}
							
						}

						if(sp.getKeySiteMapPagePath()!= null){
							
							System.out.println("Checkin for "+sp.getKeySiteMapPagePath()+"  in >>>htmlMap");
							String htmlPathFromTeamSite=htmlMap.get(sp.getKeySiteMapPagePath());
							
							
							if(htmlPathFromTeamSite !=null) {
						   //System.out.println("htmlPathFromTeamSite >>>>>"+htmlPathFromTeamSite);
							sp.setContainsIndexHTML(Boolean.TRUE);
							//System.out.println("Contain index File is >>>>>>"+sp.toString());
							}
							else {
								//System.out.println("Contain index File is >>>>>>"+sp.toString());
								httpstatusNotVlid.add(sp);
							}
						}
					}

					//System.out.println("Count of HTTP_STATUS_CODE  invalid >>"+httpstatusNotVlid.toString() );
					//System.out.println("Count of NO TEAMSITE PAGE AVAILABE   >>"+teamsitePageNotVlid.size() );
					//System.out.println("Count of NO INDEC HTML AVAILABLE >>"+httpstatusNotVlid.size() );
					
					//System.out.println("Count of NO INDEC HTML AVAILABLE >>"+translatedSitemapurls.toString() );
					
					String ReportFile = TeamSiteCommonUtils.generateReport(translatedSitemapurls);
				}
				
				
				else {
					System.out.println("Sitemap File is not available for >>"+workareaPath );
				}

				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSAuthenticationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSRemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				client.endSession();
			}
}


	


		// TODO Auto-generated method stub
		
        
}
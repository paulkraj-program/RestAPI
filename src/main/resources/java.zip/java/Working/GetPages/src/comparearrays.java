import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class comparearrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "jeep,swift,jaguar,audi,bmw,benz";
		String[] list = s.split(",");
		System.out.println(""+Arrays.toString(list));
		String c="jeep, swift";
		
		String[] checked = c.replaceAll("\\s","").split(",");

		HashSet<String> s1 = new HashSet<String>(Arrays.asList(list));
		s1.removeAll(Arrays.asList(checked));
		System.out.println("si is >>>"+s1);
		String g = String.join(",", s1);
		System.out.println(">>>"+g);
		
		String h = "audi";
		String[] m = h.split(",");
		System.out.println("m>>>"+m[0]);
		
		
		Map<String,String> mParameters = new HashMap<String,String>(); 
		mParameters.put("title", "abc");
		mParameters.put("keywords", "def");
		mParameters.put("description", "");
		mParameters.put("industry", "");
		mParameters.put("country", "");
		mParameters.put("language", "");
		
		System.out.println("Printing "+mParameters.toString());
		
		
		String[] alphabet = new String[]{"AA", "B", "C"};

        // Convert String Array to List
        List<String> lista = Arrays.asList(alphabet);

        if(lista.contains("A")){
            System.out.println("Hello A");
        }
        String v = "AFilterTypeu";
        System.out.println("V is >> "+v);
        
        if(v.contains("(")) {
        	
        	System.out.println("Yes");
        }
        
        Pattern p = Pattern.compile("\\((.*?)\\)");
        Matcher kk = p.matcher(v);

        while(kk.find()) {
        	v = kk.group(1);
            
        }
        System.out.println("The String after conversion is "+ v);
	}
	

}

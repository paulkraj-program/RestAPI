package com.interwoven.teamsite;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.dom4j.Document;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.wcm.lscs.Client;

public class CSClientConnection {

	public static void main(String[] args) throws IOException {
		Properties prop = new Properties();
        try {
        	
			prop.load(new FileInputStream(new File("/opentext/TeamSite/cssdk/cssdk.cfg")));
			CSClient client = Connection.getTeamSiteCSClient(prop);
			System.out.println("CSCLient is >>."+client.isValid());
			
			
			 
			
		} catch (CSException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
	}
}

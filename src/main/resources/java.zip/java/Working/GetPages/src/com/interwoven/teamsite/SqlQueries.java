package com.interwoven.teamsite;

public class SqlQueries {

	public static final String GETCATEGORY_QUERY = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA='tsdb_cat'";
	public static final String GETPRODUCTCATEGORY_QUERY = "SELECT DISTINCT category FROM ";
	public static final String GETPRODUCTSUBCATEGORY_QUERY = "select  GROUP_CONCAT(distinct subcategory SEPARATOR '|') as subcategory from <TABLE_NAME> where category=?";
	public static final String GETPRODUCTRANGE_QUERY ="select  w.category ,min(cast(w.value AS SIGNED)) AS Min ,max(cast(w.value AS SIGNED)) AS Max from (select category ,value from <TABLE_NAME> where filter='range') w group by w.category";
}

package com.interwoven.teamsite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

public class RetrieveResultSet {
	private static final String GETCATEGORY = "GETCATEGORY";
	private static final String GETPRODUCTRANGE = "GETPRODUCTRANGE";
	public static Connection getConnection() {

		Connection conn = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			 conn=DriverManager.getConnection("jdbc:mysql://teamsite16rdsd.marketing-devl.us.i06.c01.johndeerecloud.com:3306/tsdb_cat","tsdbuser","ddHF8LL5DFN7qTry");  
			System.out.println("[getConnection] Connected to database..");
		} catch (Exception e) {

			System.out.println("[getConnection] error in connecting to the database is " + e.getMessage());
		}
		return conn;

	}
	public static Map<String,String> retrieveConfigAttributes(String requestParams, String configAttribute) throws SQLException {
		
		PreparedStatement stmt = null;
		Statement state = null;
		Map<String,String> mp = new LinkedHashMap<String,String>();
		List<String> result = new ArrayList<String>();
		ResultSet rs = null;
		ResultSet subrs = null;
		Document document = DocumentHelper.createDocument();
		@SuppressWarnings("unused")
		Document configDataDocument = DocumentHelper.createDocument();
		CreateXMLDocument xmlObj = new CreateXMLDocument();
		Connection conn = RetrieveResultSet.getConnection();
		String retrieveQuery = new String();
		String retrieveSubCatQuery = new String();
		if (configAttribute.equalsIgnoreCase(GETCATEGORY)) {
			String s ="utilitytractor_product_information";
			retrieveQuery = SqlQueries.GETPRODUCTCATEGORY_QUERY+s;
			retrieveSubCatQuery = SqlQueries.GETPRODUCTSUBCATEGORY_QUERY;
			retrieveSubCatQuery = retrieveSubCatQuery.replaceAll("<TABLE_NAME>", s);
			
			try {
		
				state = (Statement) conn.createStatement();
				//stmt.setString(1,s);
				System.out.println("[retrieveConfigAttributes] final query is: "+retrieveSubCatQuery );
				rs = state.executeQuery(retrieveQuery);
				
				
				
				

				System.out.println("[retrieveConfigAttributes] query executed");

				while (rs.next()) {
					if(!(rs.getString("category").equalsIgnoreCase("Model Number")) && !(rs.getString("category").equalsIgnoreCase("SKU")) && !(rs.getString("category").equalsIgnoreCase("Model Series"))) {
						result.add(rs.getString("category"));
				        }
					
					System.out.println("Segments: " + rs.getString("category"));
				}
				//Collections.sort((List<String>) (List<?>) result);
				//System.out.println("final resultSet for " + configAttribute + ": " + result);
				
				for(String a :result) {
					
					stmt = (PreparedStatement) conn.prepareStatement(retrieveSubCatQuery);
					stmt.setString(1, a);
					
					System.out.println("Segments: >>>>"+stmt.asSql());
					subrs = stmt.executeQuery();
					
					while (subrs.next()) {
						
						System.out.println(">>>>>>"+subrs.getString("subcategory"));
						
						mp.put(a,subrs.getString("subcategory"));
					}
					
					
					
					
				}
				System.out.println(">>>"+mp.toString());
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				System.out.println("Closing the connection");
				conn.close();
			}
			
		}
		
		if (configAttribute.equalsIgnoreCase(GETPRODUCTRANGE)) {
			String s ="largetractor_product_information";
			retrieveQuery = SqlQueries.GETPRODUCTCATEGORY_QUERY+s;
			retrieveSubCatQuery = SqlQueries.GETPRODUCTRANGE_QUERY;
			retrieveSubCatQuery = retrieveSubCatQuery.replaceAll("<TABLE_NAME>", s);
			
			try {
		
				state = (Statement) conn.createStatement();
				//stmt.setString(1,s);
				System.out.println("[retrieveConfigAttributes] final query is: "+retrieveSubCatQuery );
				rs = state.executeQuery(retrieveSubCatQuery);
				
				
				
				

				System.out.println("[retrieveConfigAttributes] query executed");

				while (rs.next()) {
					
				
					System.out.println(">> "+rs.getString("category") + ">>"+rs.getString("Min") + "|" + rs.getString("Max"));
						//result.add(rs.getString("category"));
				        }
					
					//System.out.println("Segments: " + rs.getString("category"));
				
				//Collections.sort((List<String>) (List<?>) result);
				//System.out.println("final resultSet for " + configAttribute + ": " + result);
				
				
					
					
					
					
				
				System.out.println(">>>"+mp.toString());
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				System.out.println("Closing the connection");
				conn.close();
			}
			
		}
		
		return mp;
		
	}
}

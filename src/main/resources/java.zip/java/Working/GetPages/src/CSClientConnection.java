import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.interwoven.cssdk.access.CSGroup;
import com.interwoven.cssdk.access.CSPermissionEntry;
import com.interwoven.cssdk.access.CSPrincipal;
import com.interwoven.cssdk.access.CSRole;
import com.interwoven.cssdk.access.CSUser;
import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.common.CSIterator;
import com.interwoven.cssdk.filesys.CSAssociation;
import com.interwoven.cssdk.filesys.CSFile;
import com.interwoven.cssdk.filesys.CSSimpleFile;
import com.interwoven.cssdk.filesys.CSVPath;
import com.interwoven.cssdk.filesys.CSWorkarea;
import com.interwoven.wcm.lscs.Client;

public class CSClientConnection {

	static Map<String,String> mParameters;
	public static void main(String[] args) throws IOException {
		Properties prop = new Properties();
		
        try {
        	
			prop.load(new FileInputStream(
			        new File("/opentext/TeamSite/local/bin/custom/URLContentCleanUp/config.properties")));
			CSClient client = Connection.getTeamSiteCSClient(prop);
			System.out.println("CSCLient is >>."+client.isValid());
			CSGroup PrivateGroup = client.getGroup("dce-cms-lock", true);
			Boolean run =true;
			 long start = System.currentTimeMillis();
			 String file ="/default/main/deere/de/de/WORKAREA/shared/sites/deere/de/de/website/industries/agriculture/index.page";
			 String[] alphabet = new String[]{"industry", "language", "country"};
			 List<String> lista = Arrays.asList(alphabet);

		        
			 
				CSVPath waPath = new CSVPath(file);
				System.out.println("CSVPath to string is >>>"+waPath.getAreaRelativePath().getParentPath().toString());
				System.out.println("CSVPath to string is >>>"+waPath.toString());
				CSWorkarea csWorkarea = client.getWorkarea(waPath.getArea(), false);
				System.out.println("csWorkarea check "+waPath.getAreaRelativePath().toString());
				String usedID = "hb29529";
				CSFile csf = client.getFile(waPath);
				System.out.println("CSFile to string is >>>"+csf.getUAI().toString());
				System.out.println("CSFile to string is >>>"+csf.toString());
				
				//mParameters = getParameterValues(csf.getUAI().toString(),"");
				
				CSSimpleFile simpleFile = (CSSimpleFile) csf;
                Document document = null;
				
				// Load the DCR or LiveSite page document from TeamSite
				try (InputStream input = new BufferedInputStream(simpleFile.getInputStream(true))) {
					document = new org.dom4j.io.SAXReader().read(input);
					
					List<Node> metatagNodes = document.selectNodes("/Page/Page_Display_Properties/MetaTags");
					
					for (Node node : metatagNodes) {
			            Element element = (Element)node;
			            
			            Iterator<Element> iterator = element.elementIterator("MetaTag");
			            while(iterator.hasNext()) {
				               Element pageElement = (Element)iterator.next();
				               String a = pageElement.selectSingleNode("name").getText();
				               System.out.println("Name value is  >>>>>>>>>>>>"+a);
				               if(lista.contains(a)) {
				            	   System.out.println("Contais >>>>");
				            	   pageElement.selectSingleNode("content").setText("got it");
				            	   
				               }
				               
			            }
			            }
				} catch (DocumentException | IOException e) {
					throw new CSException(e);
				}
				try (InputStream input = new BufferedInputStream(simpleFile.getInputStream(true))) {
					
					
					List<Node> metatagNodes = document.selectNodes("/Page/Page_Display_Properties/MetaTags");
					
					for (Node node : metatagNodes) {
			            Element element = (Element)node;
			            
			            Iterator<Element> iterator = element.elementIterator("MetaTag");
			            while(iterator.hasNext()) {
				               Element pageElement = (Element)iterator.next();
				               String a = pageElement.selectSingleNode("name").getText();
				               String b = pageElement.selectSingleNode("content").getText();
				               System.out.println("Checking ......Name value is  >>>>>>>>>>>>"+a);
				               System.out.println("Checking ......Content value is  >>>>>>>>>>>>"+b);
				               
				               
			            }
			            }
				} catch (IOException e) {
					throw new CSException(e);
				}
				
				
				
				
				
				
				
				if (csf.isModified()){
					System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Modified by Owner>>>>>>>>>>>>>>>>>>>>>>>> "+csf.getOwner().getFullName());
				}
				if (csf.isLocked()){
					
					System.out.println("Locked by Owner "+csf.getLockOwner().getName());
					System.out.println("Locked by Creator "+csf.getLockCreator().getName());
				}

				//csf.setGroup(PrivateGroup);
				CSIterator privateGroupUsers = PrivateGroup.getUsers(true);
				if(!run) {
				while (privateGroupUsers.hasNext()) {
	                 CSUser groupUser = (CSUser) privateGroupUsers.next();
	                 System.out.println("checkin if "+groupUser.getName()+">> mactches "+usedID);
	                 if(groupUser.getName().equalsIgnoreCase(usedID)){
	                	 System.out.println("Matched >>>>>>>>>>>>>");
	                	
	                	 
	                	 //csf.setPermissionsInherited(false);
	                	 csf.setOwner(groupUser);
	                	 int g = csf.getUnixPermissionMode();
	                	 System.out.println("Prmision mode is>>"+g);
	                	 
	                	csf.setUnixPermissionMode(504);
	                	
	                	System.out.println("Prmision csf.getPermissions() after setting is>>"+csf.getUnixPermissionMode());
	                	
	                	break;
	                	 
	                 }         
	                 
				}
				
				}
				String group ="dce-cms-cpw-schedule";
				
				if(!run) {
				CSGroup groupReview = client.getGroup(group, true);
				System.out.println(">>>>>>"+groupReview.getDisplayName());
				CSIterator groupUsers = groupReview.getUsers(true);
	             while (groupUsers.hasNext()) {
	                 CSUser groupUser = (CSUser) groupUsers.next();
	                 String groupUserEmail = groupUser.getEmailAddress();
	                 System.out.println(">>>>>>"+groupUser.getDisplayName());
	             }
				}
			/*
			 * CSAssociation[] c = csf.getChildAssociations(null, false, false);
			 * for(CSAssociation ca :c) {
			 * 
			 * System.out.println("Primary Association >>>"+ca.getPrimary().toString());
			 * System.out.println("Secondary Association >>>"+ca.getSecondary().getUAI());
			 * 
			 * 
			 * }
			 */
			
		} catch (CSException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
	}
	public static Map<String, String> getParameterValues(String filePath, String parameters) {
		// TODO Auto-generated method stub
		
		File fXmlFile = new File("/iwmnt"+"/"+filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		try {
			dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);

			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			org.w3c.dom.Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("Page_Display_Properties");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				org.w3c.dom.Node nNode = nList.item(temp);

				

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
	                

					if(!((org.w3c.dom.Element) eElement).getElementsByTagName("Title").item(0).getTextContent().equalsIgnoreCase("")) {
					String title= ((org.w3c.dom.Element) eElement).getElementsByTagName("Title").item(0).getTextContent().toString();
					System.out.println("title>>>>"+title);
					
					}
					if(!((org.w3c.dom.Element) eElement).getElementsByTagName("Keywords").item(0).getTextContent().equalsIgnoreCase("")) {
						String keywords=((org.w3c.dom.Element) eElement).getElementsByTagName("Keywords").item(0).getTextContent().toString();
						System.out.println("keywords>>>>"+keywords);
					}
					if(!((org.w3c.dom.Element) eElement).getElementsByTagName("Description").item(0).getTextContent().equalsIgnoreCase("")) {
						String description =((org.w3c.dom.Element) eElement).getElementsByTagName("Description").item(0).getTextContent().toString();
						System.out.println("description>>>>"+description);
					}
					
					
					NodeList MetaNodeList = ((org.w3c.dom.Element) eElement).getElementsByTagName("MetaTags");
					for (int itemp = 0; itemp < MetaNodeList.getLength(); itemp++) {
						org.w3c.dom.Node MetaNode = MetaNodeList.item(itemp);
						if (MetaNode.getNodeType() == Node.ELEMENT_NODE) {
							
							org.w3c.dom.Element MetaNodeElement = (org.w3c.dom.Element) MetaNode;
							
							NodeList MetaList = ((org.w3c.dom.Element) MetaNodeElement).getElementsByTagName("MetaTag");
							for (int ntemp = 0; ntemp < MetaList.getLength(); ntemp++) {
								org.w3c.dom.Node MetatagNode =  MetaList.item(ntemp);
								org.w3c.dom.Element MetaElement = (org.w3c.dom.Element) MetatagNode;
								String name =((org.w3c.dom.Element) MetaElement).getElementsByTagName("name").item(0).getTextContent();
								String content= ((org.w3c.dom.Element) MetaElement).getElementsByTagName("content").item(0).getTextContent();
								System.out.println("name>>>>"+name);
								System.out.println("content>>>>"+content);
							
							}
						}
					}						
					
					
				}
			}
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}

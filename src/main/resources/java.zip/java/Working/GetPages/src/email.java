

import java.io.File;
import java.util.Date;
import java.util.Hashtable;

import com.interwoven.cssdk.common.CSClient;
import com.interwoven.cssdk.common.CSException;
import com.interwoven.cssdk.workflow.CSExternalTask;
import com.interwoven.cssdk.workflow.CSURLExternalTask;
import com.interwoven.serverutils100.IWConfig;

import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class email {

	private static final  Logger LOGGER = Logger.getLogger(email.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  String from = "TeamSiteAdmin@johndeere.com";
          String to = "rajpaul@johndeere.com";
		  String subject = "Testing";
		 
		  String ReportStatus = "yes";
		  
		 

		
		 
		  Properties properties = System.getProperties();
		 
		  properties.put("mail.smtp.host","localhost");
		 
		  properties.put("mail.smtp.port", "25");
		 
		  Session session = Session.getDefaultInstance(properties, null);
		  
		  try
		  {
		      // create a message
		      MimeMessage msg = new MimeMessage(session);
		      msg.setFrom(new InternetAddress(from));
		      InternetAddress[] address = {new InternetAddress(to)};
		      msg.setRecipients(Message.RecipientType.TO, address);
		      msg.setSubject(subject);
		 
		      // create and fill the first message part
		      Multipart mp = new MimeMultipart();
		      MimeBodyPart mbp1 = new MimeBodyPart();
		     
		      String msgText1 = new String();
		      if(ReportStatus.equalsIgnoreCase("yes")) {
		    	  msgText1 = "Yes";
		    	  File filename = new File("/tmp/DeletedFiles_1357079.xlsx");
				  MimeBodyPart mbp2 = new MimeBodyPart();
			      FileDataSource fds = new FileDataSource(filename);
			      mbp2.setDataHandler(new DataHandler(fds));
			      mbp2.setFileName(fds.getName());
			      mp.addBodyPart(mbp2);
		      }
		      else { 
		    	  msgText1 = "No";
		    	  }
			  mbp1.setText(msgText1);
			  mp.addBodyPart(mbp1);

		      // add the Multipart to the message
		      msg.setContent(mp);
		 
		      // set the Date: header
		      //msg.setSentDate(new Date());
		       
		      // send the message
		      System.out.println("Sending Email");
		      Transport.send(msg);
		       
		  } 
		  catch (MessagingException mex) 
		  {
		      mex.printStackTrace();
		      Exception ex = null;
		      if ((ex = mex.getNextException()) != null) {
		    ex.printStackTrace();
		      }
		  }

		
		
	}
	
}







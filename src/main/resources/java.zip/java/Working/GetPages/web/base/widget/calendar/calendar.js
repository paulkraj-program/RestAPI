
var isNav = false;
var isIE  = false;

if (navigator.appName == "Netscape") {
    isNav = true;
} else {
    isIE = true;
}

selectedLanguage = navigator.language;

buildCalParts();

function buildCalendar(initialDate) {
    setInitialDate(initialDate);
    
    // Fill in the top frame.
    var doc = top.frames["topCalFrame"].document;
    doc.open();
    doc.writeln(buildTopCalFrame());
    doc.close();

    // Fill in the bottom frame.
    doc = top.frames["bottomCalFrame"].document;
    doc.open();
    doc.writeln(buildBottomCalFrame());
    doc.close();
	getHourSelect();
	getMinuteSelect();
}

var initialStartDate = null;
var today = new Date();

function setInitialDate(inDate) {
   
    // Create a new date object (will generally parse correct date except when
    // "." is used as a delimiter)  This routine does *not* catch all date
    // formats, if you need to parse a custom date format, do it here
    calDate = new Date(inDate);

    // If the incoming date is invalid, use the current date
    if (isNaN(calDate)) {

        // Add custom date parsing here
        // If it fails, simply create a new date object which defaults to the
        // current date
        calDate = new Date();
    }

    if (initialStartDate == null)
    {
        initialStartDate = new Date(calDate);
    }

    // Keep track of the current day value
    calDay  = calDate.getDate();

    // Set day value to 1... to avoid JavaScript date calculation anomalies
    // (if the month changes to Feb and the day is 30, the month would change
    // to March and the day would change to 2.  Setting the day to 1 will
    // prevent that)
    calDate.setDate(1);
}

function makeButton(imgName, alt, action) {
    var imagePathName = "../../images/" + imgName;

    var html = "<td width='1'><a href='#' onclick='" + action + ";return false;'><img src='" + imagePathName + "' width='16' height='16' border='0' alt='" + alt + "'></a></td>"
    return html;
}

function buildTopCalFrame() {
    var prevYear  = makeButton("icn_pageleft2_calendar.gif", calendar_skin.previous_year, "javascript:parent.setPreviousYear()");
    var prevMonth = makeButton("icn_pageleft_calendar.gif",  calendar_skin.previous_month,  "javascript:parent.setPreviousMonth()");
    var nextMonth = makeButton("icn_pageright_calendar.gif", calendar_skin.next_month,  "javascript:parent.setNextMonth()");
    var nextYear  = makeButton("icn_pageright2_calendar.gif", calendar_skin.next_year, "javascript:parent.setNextYear()");

    // Create the top frame of the calendar
    var calDoc =
        "<HTML>\n" +
        "<HEAD>\n" +
        "<LINK REL=\"stylesheet\" type=\"text/css\" href=\"/iw-cc/base/styles/iw.css\">\n" +
        "</HEAD>\n" +
        "<BODY style='margin:10px' class='iw-base-calendar-body'>\n" +
        "<FORM NAME='calControl' onSubmit='return false;'>\n" +
        "<table width='100%' border='0' cellspacing='0' cellpadding='2' style='background-color: #cccccc; margin-bottom: 5px;'>\n" +
        prevYear  + "\n" +
        prevMonth + "\n" +
		"<td width='100%' align='center'><span class='iw-base-calendar-month'>" + getMonthSelect() + "</span></td>\n" +
        "<TD COLSPAN='1' ALIGN='center'>" +
        "<INPUT CLASS='iw-base-text' NAME='year' VALUE='" + calDate.getFullYear() + "' TYPE='TEXT' SIZE=4 MAXLENGTH=4 onChange='parent.setYear()'>" +
        "</TD>" +
        nextMonth + "\n" +
        nextYear  + "\n" +
        "</table>" +
        "</FORM>\n" +
        "</BODY>\n" +
        "</HTML>\n";
    return calDoc;
}

function buildBottomCalFrame() {       

    // Start calendar document
    var calDoc = calendarBegin;

    // Get month, and year from global calendar date
    month   = calDate.getMonth();
    year    = calDate.getFullYear();


    // Get globally-tracked day value (prevents JavaScript date anomalies)
    day     = calDay;

    var i   = 0;

    // Determine the number of days in the current month
    var days = getDaysInMonth();

    // If global day value is > than days in month, highlight last day in month
    if (day > days) {
        day = days;
    }

    // Determine what day of the week the calendar starts on
    var firstOfMonth = new Date (year, month, 1);

    // Get the day of the week the first day of the month falls on
    var startingPos  = firstOfMonth.getDay();
    days += startingPos;

    // Keep track of the columns, start a new row after every 7 columns
    var columnCount = 0;

    // Make beginning non-date cells blank
    for (i = 0; i < startingPos; i++) {

        calDoc += blankCell;
	columnCount++;
    }

    // Set values for days of the month
    var currentDay = 0;
    var dayType    = "weekday";

    // Date cells contain a number
    for (i = startingPos; i < days; i++) {

	var paddingChar = "&nbsp;";

        // Adjust spacing so that all links have relatively equal widths
        if (i-startingPos+1 < 10) {
            padding = "&nbsp;&nbsp;";
        }
        else {
            padding = "&nbsp;";
        }

        // Get the day currently being written
        currentDay = i-startingPos+1;

        // Add the day to the calendar string
        var dayJS = "javascript:parent.returnDate(" + currentDay + ");return false;";
        var className = "iw-base-calendar-date";

        var thisDate = new Date (year, month, currentDay);

        if (thisDate.getDate() == today.getDate() && 
            thisDate.getMonth() == today.getMonth() && 
            thisDate.getFullYear() == today.getFullYear())
        {
            className = "iw-base-calendar-today";
        }

        if (thisDate.getDate() == initialStartDate.getDate() && 
            thisDate.getMonth() == initialStartDate.getMonth() && 
            thisDate.getFullYear() == initialStartDate.getFullYear())
        {
            className = "iw-base-calendar-date-select";
        }
      
        calDoc += "<td><a href='#' onclick='" + dayJS + "' class='" + className + "'>" + currentDay + "</a></td>";

        columnCount++;

        // Start a new row when necessary
        if (columnCount % 7 == 0) {
            calDoc += "</TR>\n<TR>";
        }
    }

    // Make remaining non-date cells blank
    for (i=days; i<42; i++)  {

        calDoc += blankCell;
        columnCount++;

        // Start a new row when necessary
        if (columnCount % 7 == 0) {
            calDoc += "</TR>\n";
            if (i<41) {
                calDoc += "<TR>";
            }
        }
    }

    // Finish the new calendar page
    calDoc += calendarEnd;

    // Return the completed calendar page
    return calDoc;
}

function writeCalendar() {

    // Create the new calendar for the selected month & year
    calDocBottom = buildBottomCalFrame();

    // Write the new calendar to the bottom frame
    top.frames['bottomCalFrame'].document.open();
    top.frames['bottomCalFrame'].document.write(calDocBottom);
    top.frames['bottomCalFrame'].document.close();
	getHourSelect();
	getMinuteSelect();
}

function setToday() {

    // Set the calendar to today's date, month and year
    calDate.setDate(today.getDate());
    calDate.setMonth(today.getMonth());
    calDate.setFullYear(today.getFullYear());
	calDate.setHours(today.getHours());
	calDate.setMinutes(today.getMinutes());

    // Set month in drop-down list
    top.frames['topCalFrame'].document.calControl.month.selectedIndex = calDate.getMonth();

    // Set year value
    top.frames['topCalFrame'].document.calControl.year.value = calDate.getFullYear();

    // Display the new calendar
    writeCalendar();
}

function setYear() {

    // Get the new year value
    var year  = top.frames['topCalFrame'].document.calControl.year.value;

    // If it's a four-digit year then change the calendar
    if (isFourDigitYear(year)) {
        calDate.setFullYear(year);
        writeCalendar();
    }
    else {
        // Highlight the year if the year is not four digits in length
        top.frames['topCalFrame'].document.calControl.year.focus();
        top.frames['topCalFrame'].document.calControl.year.select();
    }
}

function setCurrentMonth() {

    // Get the newly selected month and change the calendar accordingly
    var month = top.frames['topCalFrame'].document.calControl.month.selectedIndex;

    calDate.setMonth(month);
    writeCalendar();
}

function setPreviousYear() {

    var year  = top.frames['topCalFrame'].document.calControl.year.value;

    if (isFourDigitYear(year) && year > 1000) {
        year--;
        calDate.setFullYear(year);
        top.frames['topCalFrame'].document.calControl.year.value = year;
        writeCalendar();
    }
}

function setPreviousMonth() {

    var year = top.frames['topCalFrame'].document.calControl.year.value;
    if (isFourDigitYear(year)) {
        var month = top.frames['topCalFrame'].document.calControl.month.selectedIndex;

        // If month is January, set month to December and decrement the year
        if (month == 0) {
            month = 11;
            if (year > 1000) {
                year--;
                calDate.setFullYear(year);
                top.frames['topCalFrame'].document.calControl.year.value = year;
            }
        }
        else {
            month--;
        }
        calDate.setMonth(month);
        top.frames['topCalFrame'].document.calControl.month.selectedIndex = month;
        writeCalendar();
    }
}

function setNextMonth() {

    var year = top.frames['topCalFrame'].document.calControl.year.value;

    if (isFourDigitYear(year)) {
        var month = top.frames['topCalFrame'].document.calControl.month.selectedIndex;

        // If month is December, set month to January and increment the year
        if (month == 11) {
            month = 0;
            year++;
            calDate.setFullYear(year);
            top.frames['topCalFrame'].document.calControl.year.value = year;
        }
        else {
            month++;
        }
        calDate.setMonth(month);
        top.frames['topCalFrame'].document.calControl.month.selectedIndex = month;
        writeCalendar();
    }
}

function setNextYear() {

    var year = top.frames['topCalFrame'].document.calControl.year.value;
    if (isFourDigitYear(year)) {
        year++;
        calDate.setFullYear(year);
        top.frames['topCalFrame'].document.calControl.year.value = year;
        writeCalendar();
    }
}

function getDaysInMonth()  {

    var days;
    var month = calDate.getMonth()+1;
    var year  = calDate.getFullYear();

    // Return 31 days
    if (month==1 || month==3 || month==5 || month==7 || month==8 ||
        month==10 || month==12)  {
        days=31;
    }
    // Return 30 days
    else if (month==4 || month==6 || month==9 || month==11) {
        days=30;
    }
    // Return 29 days
    else if (month==2)  {
        if (isLeapYear(year)) {
            days=29;
        }
        // Return 28 days
        else {
            days=28;
        }
    }
    return (days);
}

function isLeapYear (Year) {

    if (((Year % 4)==0) && ((Year % 100)!=0) || ((Year % 400)==0)) {
        return (true);
    } else {
        return (false);
    }
}

function isFourDigitYear(year) {

    if (year.length != 4) {
        top.frames['topCalFrame'].document.calControl.year.value = calDate.getFullYear();
        top.frames['topCalFrame'].document.calControl.year.select();
        top.frames['topCalFrame'].document.calControl.year.focus();
    }
    else {
        return true;
    }
}

function getMonthSelect() {

    // Determine month to set as default
    var activeMonth = calDate.getMonth();

    // Start HTML select list element
    monthSelect = "<SELECT CLASS='iw-base-combobox' NAME='month' onChange='parent.setCurrentMonth()'>";

    // Loop through month array
    for (var i = 0; i < 12; i++) {
        var monthName = fwFullMonth(i);
        // Show the correct month in the select list
        if (i == activeMonth) {
            monthSelect += "<OPTION SELECTED>" + monthName + "</OPTION>\n";
        }
        else {
            monthSelect += "<OPTION>" + monthName + "</OPTION>\n";
        }
    }
    monthSelect += "</SELECT>";

    // Return a string value which contains a select list of all 12 months
    return monthSelect;
}


function createWeekdayList() {

    // Start HTML to hold weekday names in table format
    var weekdays = "<TR>";

    // Loop through weekday array
    for (var i = 0; i < 7; i++) {

        weekdays += "<TH class='iw-base-calendar-day'>" + fwShortDay(i) + "</TH>";
    }
    weekdays += "</TR>\n";

    // Return table row of weekday abbreviations to display above the calendar
    return weekdays;
}


function buildCalParts() {

    // Generate weekday headers for the calendar
    weekdays = createWeekdayList();

    // Build the blank cell rows
    blankCell = "<TD align=center class='iw-base-calendar-date'>&nbsp;&nbsp;&nbsp;</TD>";

    // Build the top portion of the calendar page using CSS to control some
    // display elements
    calendarBegin =
        "<HTML>\n" +
        "<HEAD>\n" +
        "<LINK REL=\"stylesheet\" type=\"text/css\" href=\"/iw-cc/base/styles/iw.css\">\n" +
        "</HEAD>\n" +
        "<BODY style='margin-top:0px;margin-left:10px;margin-right:10px;' class='iw-base-calendar-body'>\n" +
        "<table style='table-layout:fixed; height:100%; width:100%' border='0' cellspacing='0' cellpadding='0'>\n" +
	    "<tr>\n" +
	    "<td>\n" +
        "<table width='100%' border='0' cellspacing='0' cellpadding='4' style='border-bottom: 1px solid #bbbbbb;'>\n";
   
    // Build weekday headings
    calendarBegin +=
        weekdays +
        "<TR>";
    
    // Build the bottom portion of the calendar page
    calendarEnd = "";

    // End the table and html document
    calendarEnd +=
        "</table>\n" +
        "</td>\n" +
        "</tr>\n" +
		"<tr>\n" +
        "<td align='center'>\n" +
        "<table border='0' cellspacing='2' cellpadding='2'>\n" +
        "    <tr>\n" +
        "        <td><span class='iw-base-heading'>Time : </span><select name='hour' id='hour'> </select>  <select name='min' id='min'> </select>  </td>\n" +
        "    </tr>\n" +
        "</table>\n" +
        "</td>\n" +
        "</tr>\n" +
        "<tr>\n" +
        "<td>\n" +
        "<table border='0' cellspacing='0' cellpadding='2'>\n" +
        "    <tr>\n" +
        "        <td nowrap><a href='#' onclick='javascript:parent.setToday();return false;' class='iw-base-link'>" + HTMLEscape(calendar_skin.today) + "</a></td>\n" +
        "        <td><img src='../../images/div_optionbar.gif' align='middle'></td>\n" +
        "        <td nowrap><a href='#' onclick='javascript:top.close();return false;' class='iw-base-link'>" + HTMLEscape(calendar_skin.cancel) + "</a></td>\n" +
        "    </tr>\n" +
        "</table>\n" +
        "</td>\n" +
        "</tr>\n" +
        "</table>\n" +
        "</body>\n" +
        "</html>\n";
}

function getHourSelect(){
	var selectHours = "";
	for(var i=0; i<window.frames.length; i++){
		var hourSelect= window.frames[i].document.getElementById('hour');
		if(hourSelect) {
			//var activeHour = calDate.getHours();
			var activeHour = today.getHours();
			for(var i = 0; i < 24; i++) {
				if(activeHour == i){
					hourSelect.options[i]=new Option(i, i, true, true)
				}else{
					hourSelect.options[i]=new Option(i, i, false, false)
				}	
				
			}
		}
	}
}

function getMinuteSelect(){
	var selectMinutes = "";
	for(var i=0; i<window.frames.length; i++){
		var minuteSelect= window.frames[i].document.getElementById('min');
		if(minuteSelect) {
			//var activeMinute = calDate.getMinutes();		 
			//for(var i = 0; i < 60; i+= 5) {
				//var j= ((i + 5 ) / 5) - 1;
			var activeMinute = today.getMinutes();		 	
			for(var i = 0; i < 60; i++) {
				if(activeMinute == i){
					minuteSelect.options[i]=new Option(i, i, true, true)
				}else{
					minuteSelect.options[i]=new Option(i, i, false, false)
				}				
			}
		}
	}
}


function doNothing() {
}

function returnDate(inDay)
{
    // inDay = the day the user clicked on
    calDate.setDate(inDay);
	for(var i=0; i<window.frames.length; i++){
		var hour= window.frames[i].document.getElementById('hour');
		if(hour) {
			calDate.setHours(hour.options[hour.selectedIndex].text);	
		}
		var minute= window.frames[i].document.getElementById('min');
		if(minute) {
			calDate.setMinutes(minute.options[minute.selectedIndex].text);	
		}
	}
	
    // Update the date on the anchor
    if (top.anchorId) {
        var anchor = top.opener.document.getElementById(top.anchorId);
        anchor.date = calDate.valueOf();
    }
    // Call the callback with the selected date.
    if (top.opener.fwCalendarCallback) {
        top.opener.fwCalendarCallback(calDate);
        top.opener.fwCalendarCallback = null;
    }
    top.close();
}
